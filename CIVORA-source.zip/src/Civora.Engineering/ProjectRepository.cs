using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace Civora.Engineering;

public sealed class ProjectRepository
{
    private readonly string _databasePath;
    private readonly JsonSerializerOptions _json = new() { WriteIndented = true };
    private string ConnectionString => new SqliteConnectionStringBuilder { DataSource = _databasePath, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString();

    public ProjectRepository(string? databasePath = null)
    {
        var dataRoot = Environment.GetEnvironmentVariable("CIVORA_DATA_DIR");
        _databasePath = databasePath ?? Path.Combine(string.IsNullOrWhiteSpace(dataRoot) ? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "CIVORA") : dataRoot, "civora.db");
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(_databasePath))!);
        Initialize();
    }

    private void Initialize()
    {
        using var c = new SqliteConnection(ConnectionString); c.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = """
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS schema_info(version INTEGER NOT NULL);
        INSERT INTO schema_info(version) SELECT 1 WHERE NOT EXISTS(SELECT 1 FROM schema_info);
        CREATE TABLE IF NOT EXISTS projects(name TEXT PRIMARY KEY COLLATE NOCASE, json TEXT NOT NULL, modified_utc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS calculation_history(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, result TEXT NOT NULL, created_utc TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS builtin_defaults(name TEXT PRIMARY KEY, json TEXT NOT NULL, library_version TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS app_overrides(name TEXT PRIMARY KEY, value REAL NOT NULL);
        """;
        cmd.ExecuteNonQuery();
        using var insert = c.CreateCommand();
        insert.CommandText = "INSERT INTO builtin_defaults(name,json,library_version) VALUES($name,$json,$version) ON CONFLICT(name) DO UPDATE SET json=excluded.json,library_version=excluded.library_version";
        insert.Parameters.Add("$version", SqliteType.Text).Value = EngineeringDefaultsLibrary.Version;
        var name = insert.Parameters.Add("$name", SqliteType.Text); var json = insert.Parameters.Add("$json", SqliteType.Text);
        foreach (var item in EngineeringDefaultsLibrary.BuiltIn) { name.Value = item.Name; json.Value = JsonSerializer.Serialize(item); insert.ExecuteNonQuery(); }
    }

    public void SaveProject(CivoraProject project)
    {
        ArgumentNullException.ThrowIfNull(project);
        project.ModifiedAt = DateTimeOffset.UtcNow;
        using var c = new SqliteConnection(ConnectionString); c.Open();
        using var cmd = c.CreateCommand();
        cmd.CommandText = "INSERT INTO projects(name,json,modified_utc) VALUES($name,$json,$date) ON CONFLICT(name) DO UPDATE SET json=excluded.json,modified_utc=excluded.modified_utc";
        cmd.Parameters.AddWithValue("$name", project.Name.Trim()); cmd.Parameters.AddWithValue("$json", JsonSerializer.Serialize(project, _json)); cmd.Parameters.AddWithValue("$date", project.ModifiedAt.ToString("O"));
        cmd.ExecuteNonQuery();
    }

    public CivoraProject? LoadProject(string name)
    {
        using var c = new SqliteConnection(ConnectionString); c.Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT json FROM projects WHERE name=$name"; cmd.Parameters.AddWithValue("$name", name);
        var json = cmd.ExecuteScalar() as string; return json is null ? null : JsonSerializer.Deserialize<CivoraProject>(json);
    }

    public IReadOnlyList<(string Name, DateTimeOffset Modified)> ListProjects()
    {
        using var c = new SqliteConnection(ConnectionString); c.Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "SELECT name,modified_utc FROM projects ORDER BY modified_utc DESC";
        using var r = cmd.ExecuteReader(); var items = new List<(string,DateTimeOffset)>();
        while(r.Read()) items.Add((r.GetString(0),DateTimeOffset.Parse(r.GetString(1))));
        return items;
    }

    public void DuplicateProject(string sourceName, string newName)
    {
        var project = LoadProject(sourceName) ?? throw new InvalidOperationException($"Project '{sourceName}' was not found.");
        if(string.IsNullOrWhiteSpace(newName)) throw new ArgumentException("Enter a project name.",nameof(newName));
        project.Name = newName.Trim(); project.ModifiedAt = DateTimeOffset.UtcNow; SaveProject(project);
    }

    public void RenameProject(string oldName,string newName,CivoraProject project)
    {
        if(string.IsNullOrWhiteSpace(newName))throw new ArgumentException("Enter a project name.",nameof(newName));
        newName=newName.Trim();if(string.Equals(oldName,newName,StringComparison.OrdinalIgnoreCase)){SaveProject(project);return;}
        project.Name=newName;project.ModifiedAt=DateTimeOffset.UtcNow;
        using var c=new SqliteConnection(ConnectionString);c.Open();using var tx=c.BeginTransaction();
        using(var exists=c.CreateCommand()){exists.Transaction=tx;exists.CommandText="SELECT COUNT(*) FROM projects WHERE name=$name";exists.Parameters.AddWithValue("$name",newName);if(Convert.ToInt32(exists.ExecuteScalar())>0)throw new InvalidOperationException($"A project named '{newName}' already exists.");}
        using(var update=c.CreateCommand()){update.Transaction=tx;update.CommandText="UPDATE projects SET name=$new,json=$json,modified_utc=$date WHERE name=$old";update.Parameters.AddWithValue("$new",newName);update.Parameters.AddWithValue("$json",JsonSerializer.Serialize(project,_json));update.Parameters.AddWithValue("$date",project.ModifiedAt.ToString("O"));update.Parameters.AddWithValue("$old",oldName);if(update.ExecuteNonQuery()==0){using var insert=c.CreateCommand();insert.Transaction=tx;insert.CommandText="INSERT INTO projects(name,json,modified_utc) VALUES($new,$json,$date)";insert.Parameters.AddWithValue("$new",newName);insert.Parameters.AddWithValue("$json",JsonSerializer.Serialize(project,_json));insert.Parameters.AddWithValue("$date",project.ModifiedAt.ToString("O"));insert.ExecuteNonQuery();}}
        tx.Commit();
    }

    public void DeleteProject(string name)
    {
        using var c = new SqliteConnection(ConnectionString); c.Open(); using var cmd = c.CreateCommand();
        cmd.CommandText = "DELETE FROM projects WHERE name=$name"; cmd.Parameters.AddWithValue("$name",name); cmd.ExecuteNonQuery();
    }

    public void SaveHistory(string title,string result)
    {
        using var c = new SqliteConnection(ConnectionString); c.Open(); using var cmd = c.CreateCommand();
        cmd.CommandText="INSERT INTO calculation_history(title,result,created_utc) VALUES($title,$result,$date)";
        cmd.Parameters.AddWithValue("$title",title);cmd.Parameters.AddWithValue("$result",result);cmd.Parameters.AddWithValue("$date",DateTimeOffset.UtcNow.ToString("O"));cmd.ExecuteNonQuery();
    }

    public IReadOnlyList<(string Title,string Result,DateTimeOffset Created)> SearchHistory(string? query=null)
    {
        using var c = new SqliteConnection(ConnectionString);c.Open();using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT title,result,created_utc FROM calculation_history WHERE $query IS NULL OR title LIKE $like OR result LIKE $like ORDER BY id DESC LIMIT 500";
        cmd.Parameters.AddWithValue("$query",(object?)query??DBNull.Value);cmd.Parameters.AddWithValue("$like",$"%{query}%");
        using var r=cmd.ExecuteReader();var list=new List<(string,string,DateTimeOffset)>();while(r.Read())list.Add((r.GetString(0),r.GetString(1),DateTimeOffset.Parse(r.GetString(2))));return list;
    }

    public IReadOnlyList<EngineeringDefault> GetEffectiveDefaults()
    {
        using var c=new SqliteConnection(ConnectionString);c.Open();using var cmd=c.CreateCommand();
        cmd.CommandText="SELECT b.json,o.value FROM builtin_defaults b LEFT JOIN app_overrides o ON o.name=b.name";
        using var r=cmd.ExecuteReader();var items=new List<EngineeringDefault>();
        while(r.Read()){var item=JsonSerializer.Deserialize<EngineeringDefault>(r.GetString(0))!;items.Add(r.IsDBNull(1)?item:item with{Value=r.GetDouble(1),Status="User override"});}
        return items;
    }

    public void SetDefaultOverride(EngineeringDefault item)
    {
        if(!item.IsEditable)throw new InvalidOperationException("This default is locked.");
        if(!double.IsFinite(item.Value))throw new ArgumentOutOfRangeException(nameof(item),"Value must be finite.");
        using var c=new SqliteConnection(ConnectionString);c.Open();using var cmd=c.CreateCommand();
        cmd.CommandText="INSERT INTO app_overrides(name,value) VALUES($name,$value) ON CONFLICT(name) DO UPDATE SET value=excluded.value";
        cmd.Parameters.AddWithValue("$name",item.Name);cmd.Parameters.AddWithValue("$value",item.Value);cmd.ExecuteNonQuery();
    }

    public void RestoreDefaults()
    {
        using var c=new SqliteConnection(ConnectionString);c.Open();using var cmd=c.CreateCommand();cmd.CommandText="DELETE FROM app_overrides";cmd.ExecuteNonQuery();
    }

    public void ExportProjectJson(CivoraProject project,string path) => File.WriteAllText(path,JsonSerializer.Serialize(project,_json));
}






