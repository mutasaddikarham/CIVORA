using System.ComponentModel;
using System.Runtime.CompilerServices;
namespace Civora.Engineering;

public sealed record EngineeringDefault(string Name, double Value, string Unit, string Category, string Provenance, string Assumptions, string Status = "Illustrative default", bool IsEditable = true);

public sealed class StructuralColumn : INotifyPropertyChanged
{
    private string _id="C1";private double _x;private double _y;private double _widthMm=300;private double _depthMm=300;private string _material="Concrete 25 MPa (example)";private string _reviewStatus="Candidate — review required";private string _notes="Conceptual location; not structurally verified.";private string _candidateReason="Preliminary grid candidate; review required.";private string _adjacentSpans="Not assessed";private string _architecturalConflicts="Not assessed — plan geometry is not recognized.";private string _missingDesignInformation="Confirm floor count, occupancy, loads, materials and design code.";private string _confidence="Low — conceptual grid only";
    public string Id {get=>_id;set=>Set(ref _id,value);}
    public double X {get=>_x;set=>Set(ref _x,value);}
    public double Y {get=>_y;set=>Set(ref _y,value);}
    public double WidthMm {get=>_widthMm;set=>Set(ref _widthMm,value);}
    public double DepthMm {get=>_depthMm;set=>Set(ref _depthMm,value);}
    public string Material {get=>_material;set=>Set(ref _material,value);}
    public string ReviewStatus {get=>_reviewStatus;set=>Set(ref _reviewStatus,value);}
    public string Notes {get=>_notes;set=>Set(ref _notes,value);}
    public string CandidateReason {get=>_candidateReason;set=>Set(ref _candidateReason,value);}
    public string AdjacentSpans {get=>_adjacentSpans;set=>Set(ref _adjacentSpans,value);}
    public string ArchitecturalConflicts {get=>_architecturalConflicts;set=>Set(ref _architecturalConflicts,value);}
    public string MissingDesignInformation {get=>_missingDesignInformation;set=>Set(ref _missingDesignInformation,value);}
    public string Confidence {get=>_confidence;set=>Set(ref _confidence,value);}
    public event PropertyChangedEventHandler? PropertyChanged;
    private void Set<T>(ref T field,T value,[CallerMemberName]string? name=null){if(EqualityComparer<T>.Default.Equals(field,value))return;field=value;PropertyChanged?.Invoke(this,new PropertyChangedEventArgs(name));}
}

public sealed class CivoraProject
{
    public string Name { get; set; } = "Untitled project";
    public string DrawingTitle { get; set; } = "Structural concept plan";
    public string? ImagePath { get; set; }
    public double? MetresPerPixel { get; set; }
    public double? CalibrationPixelDistance { get; set; }
    public double? CalibrationKnownMetres { get; set; }
    public double? CalibrationOriginXPixel { get; set; }
    public double? CalibrationOriginYPixel { get; set; }
    public double BuildingWidthM { get; set; } = 12;
    public double BuildingDepthM { get; set; } = 9;
    public double MaximumSpanM { get; set; } = 4;
    public double FloorCount { get; set; }
    public string BuildingUse { get; set; } = "Not specified";
    public string DesignCodeProfile { get; set; } = "Illustrative preliminary defaults";
    public List<StructuralColumn> Columns { get; set; } = [];
    public List<EngineeringDefault> MaterialOverrides { get; set; } = [];
    public DateTimeOffset ModifiedAt { get; set; } = DateTimeOffset.UtcNow;
}

public sealed record CalculationResult(string Title, string Formula, IReadOnlyDictionary<string, string> Inputs, IReadOnlyList<string> Steps, string Result, string Assumptions, string Limitation);
public sealed record BeamResult(double LeftReactionKn, double RightReactionKn, double MaximumMomentKnM, double MaximumShearKn);

public static class EngineeringDefaultsLibrary
{
    public const string Version = "1.0.0";
    public static IReadOnlyList<EngineeringDefault> BuiltIn { get; } =
    [
        new("Concrete compressive strength — C20 example",20,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project specification."),
        new("Concrete compressive strength — C25 example",25,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project specification."),
        new("Concrete compressive strength — C30 example",30,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project specification."),
        new("Concrete compressive strength — C35 example",35,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project specification."),
        new("Reinforcing steel yield strength — 400 example",400,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project documents."),
        new("Reinforcing steel yield strength — 420 example",420,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project documents."),
        new("Reinforcing steel yield strength — 500 example",500,"MPa","Material properties","User-requested example value","Illustrative grade; confirm project documents."),
        new("Structural steel yield strength — 250 example",250,"MPa","Material properties","User-requested example value","Illustrative grade; confirm product specification."),
        new("Structural steel yield strength — 345 example",345,"MPa","Material properties","User-requested example value","Illustrative grade; confirm product specification."),
        new("Normal-weight concrete density",2400,"kg/m³","Material densities","User-requested approximate example","Use specified project density when available."),
        new("Concrete unit weight",24,"kN/m³","Material densities","Approx. density × gravity","Preliminary estimation value; verify project mix."),
        new("Water unit weight",9.81,"kN/m³","Material densities","Approx. density × gravity","Fresh water near ordinary conditions."),
        new("Sand bulk density",1600,"kg/m³","Material densities","Illustrative default","Varies with grading and moisture; replace with measured value."),
        new("Coarse aggregate bulk density",1500,"kg/m³","Material densities","Illustrative default","Varies with source, grading and moisture."),
        new("Cement bulk density",1440,"kg/m³","Material densities","Illustrative loose bulk density","Use supplier data for procurement."),
        new("Brick dimensions — length",240,"mm","Masonry","Illustrative example","Edit to match selected brick product."),
        new("Brick dimensions — width",115,"mm","Masonry","Illustrative example","Edit to match selected brick product."),
        new("Brick dimensions — height",70,"mm","Masonry","Illustrative example","Edit to match selected brick product."),
        new("Residential floor live load",2,"kN/m²","Preliminary load values","User-requested illustrative starting value","Not a code value. Confirm occupancy and applicable local code."),
        new("Floor finish allowance",1,"kN/m²","Preliminary load values","User-requested illustrative starting value","Replace with actual finish build-up where known."),
        new("Partition allowance",1,"kN/m²","Preliminary load values","User-requested illustrative starting value","Simplified allowance only when appropriate; check layout and code."),
        new("Roof load profile — example",0.75,"kN/m²","Preliminary load values","Illustrative default","Not a code value. Determine local roof, rain, snow and maintenance loads."),
        new("Column section — 230 × 230",230,"mm","Section library","User-requested example size","Preliminary option only; not safe or suitable by default."),
        new("Column section — 230 × 300",300,"mm","Section library","User-requested example size","Preliminary option only."),
        new("Column section — 300 × 300",300,"mm","Section library","User-requested example size","Preliminary option only."),
        new("Column section — 300 × 450",450,"mm","Section library","User-requested example size","Preliminary option only."),
        new("Column section — 300 × 600",600,"mm","Section library","User-requested example size","Preliminary option only."),
        new("Default display precision",2,"decimal places","Unit preferences","Application preference","Display setting only; not calculation precision."),
        new("Default scale denominator",100,"ratio","Unit preferences","Illustrative drawing example","Check the plan title or scale bar before use."),
        new("Default reinforcing bar diameter",12,"mm","Material properties","Illustrative example","Nominal size only; project specifications control."),
        new("Concrete dry-volume factor",1.54,"—","Calculation assumptions","Illustrative quantity-estimation factor","Approximate dry material yield; verify local measurement practice."),
        new("Default drawing grid spacing",1,"m","Calculation assumptions","Illustrative project setting","Adjust to the project grid."),
        new("Design code profile",0,"—","Design code profiles","No code profile is implemented","No BNBC, ACI or other verified code checks are implemented.","Unverified",false),
        new("Concrete mix ratio — cement",1,"parts","Calculation assumptions","Illustrative nominal mix input","For material estimation only; not a mix design."),
        new("Concrete mix ratio — sand",2,"parts","Calculation assumptions","Illustrative nominal mix input","For material estimation only; edit or use approved mix design."),
        new("Concrete mix ratio — aggregate",4,"parts","Calculation assumptions","Illustrative nominal mix input","For material estimation only; edit or use approved mix design.")
    ];
}





