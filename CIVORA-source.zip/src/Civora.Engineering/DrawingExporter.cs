using System.Globalization;
using System.Text;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace Civora.Engineering;

public static class DrawingExporter
{
    static DrawingExporter() => QuestPDF.Settings.License = LicenseType.Community;
    private static string Q(string value) => "\"" + value.Replace("\"", "\"\"") + "\"";

    public static void ExportScheduleCsv(CivoraProject project,string path)
    {
        var b=new StringBuilder();b.AppendLine("Column ID,Grid / location,X (m),Y (m),Width (mm),Depth (mm),Material,Review status,Notes,Candidate reason,Adjacent spans,Architectural conflicts,Missing design information,Confidence");
        foreach(var c in project.Columns.OrderBy(c=>c.Y).ThenBy(c=>c.X))
            b.AppendLine(string.Join(",",new[]{Q(c.Id),Q($"{c.X:0.###}, {c.Y:0.###}"),c.X.ToString("0.###",CultureInfo.InvariantCulture),c.Y.ToString("0.###",CultureInfo.InvariantCulture),c.WidthMm.ToString("0.###",CultureInfo.InvariantCulture),c.DepthMm.ToString("0.###",CultureInfo.InvariantCulture),Q(c.Material),Q(c.ReviewStatus),Q(c.Notes),Q(c.CandidateReason),Q(c.AdjacentSpans),Q(c.ArchitecturalConflicts),Q(c.MissingDesignInformation),Q(c.Confidence)}));
        File.WriteAllText(path,b.ToString(),new UTF8Encoding(true));
    }

    public static void ExportDxf(CivoraProject project,string path)
    {
        var s=new StringBuilder();
        s.Append("0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n9\n$INSUNITS\n70\n4\n0\nENDSEC\n");
        s.Append("0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n6\n");
        foreach(var (name,color) in new[]{("STRUCTURAL_GRID",8),("PRELIMINARY_BEAMS",4),("COLUMNS",3),("DIMENSIONS",7),("ANNOTATIONS",6),("ARCHITECTURAL_BACKGROUND",9)})
            s.Append($"0\nLAYER\n2\n{name}\n70\n0\n62\n{color}\n6\nCONTINUOUS\n");
        s.Append("0\nENDTAB\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n");
        var width=Math.Max(project.BuildingWidthM,0.01)*1000;var depth=Math.Max(project.BuildingDepthM,0.01)*1000;
        Line(s,0,0,width,0,"STRUCTURAL_GRID");Line(s,width,0,width,depth,"STRUCTURAL_GRID");Line(s,width,depth,0,depth,"STRUCTURAL_GRID");Line(s,0,depth,0,0,"STRUCTURAL_GRID");
        foreach(var x in project.Columns.Select(c=>Math.Round(c.X,3)).Distinct())Line(s,x*1000,0,x*1000,depth,"STRUCTURAL_GRID");
        foreach(var y in project.Columns.Select(c=>Math.Round(c.Y,3)).Distinct())Line(s,0,y*1000,width,y*1000,"STRUCTURAL_GRID");
        foreach(var row in project.Columns.GroupBy(c=>Math.Round(c.Y,3))){var a=row.OrderBy(c=>c.X).ToArray();for(var i=1;i<a.Length;i++)Line(s,a[i-1].X*1000,a[i-1].Y*1000,a[i].X*1000,a[i].Y*1000,"PRELIMINARY_BEAMS");}
        foreach(var c in project.Columns){var x=c.X*1000;var y=c.Y*1000;var hx=c.WidthMm/2;var hy=c.DepthMm/2;Line(s,x-hx,y-hy,x+hx,y-hy,"COLUMNS");Line(s,x+hx,y-hy,x+hx,y+hy,"COLUMNS");Line(s,x+hx,y+hy,x-hx,y+hy,"COLUMNS");Line(s,x-hx,y+hy,x-hx,y-hy,"COLUMNS");Text(s,x+hx+50,y+hy+50,180,c.Id,"ANNOTATIONS");}
        Text(s,0,depth+500,250,$"{project.Name} — {project.DrawingTitle}","ANNOTATIONS");
        Text(s,0,depth+200,130,$"PRELIMINARY | Units mm | {DateTime.Now:yyyy-MM-dd} | Design code not verified","ANNOTATIONS");
        s.Append("0\nENDSEC\n0\nEOF\n");File.WriteAllText(path,s.ToString(),Encoding.ASCII);
    }

    public static void ExportDrawingPdf(CivoraProject project,string path)
    {
        Document.Create(document=>document.Page(page=>
        {
            page.Size(PageSizes.Letter.Landscape());page.Margin(30);page.PageColor(Colors.White);
            page.DefaultTextStyle(x=>x.FontFamily("Lato").FontSize(9).FontColor(Colors.Grey.Darken4));
            page.Header().Column(header=>
            {
                header.Item().Text("CIVORA  |  STRUCTURAL CONCEPT DRAWING").FontSize(17).Bold().FontColor("#10253B");
                header.Item().Text($"{Clean(project.Name)}  •  {Clean(project.DrawingTitle)}  •  {DateTime.Now:yyyy-MM-dd}").FontSize(9).FontColor("#41566B");
            });
            page.Content().Column(column=>
            {
                column.Spacing(8);
                column.Item().Row(row=>
                {
                    row.RelativeItem().Text($"Footprint: {project.BuildingWidthM:0.##} × {project.BuildingDepthM:0.##} m   |   Columns: {project.Columns.Count}   |   Units: metres");
                    row.ConstantItem(210).AlignRight().Text($"Building use: {Clean(project.BuildingUse)}   |   Floors: {(project.FloorCount>0?project.FloorCount.ToString("0.##"):"not specified")}");
                });
                column.Item().Height(385).Border(0.8f).BorderColor("#A9B7C5").Padding(10).Svg(size=>DrawingSvg(project,size.Width,size.Height));
                column.Item().Text("PRELIMINARY ESTIMATE — DESIGN CODE NOT VERIFIED. This fit-to-page schematic is not a construction drawing; verify printed scale. Candidate columns and beam lines require qualified engineering review.")
                    .FontSize(8).Bold().FontColor("#8B5D00");
            });
            page.Footer().AlignCenter().Text("CIVORA • Concept only • Raster architectural background omitted • Revision 0").FontSize(8).FontColor("#536779");
        })).GeneratePdf(path);
    }

    public static void ExportCalculationReportPdf(string projectName,IReadOnlyList<(string Title,string Result,DateTimeOffset Created)> history,string path)
    {
        Document.Create(document=>document.Page(page=>
        {
            page.Size(PageSizes.A4);page.Margin(38);page.PageColor(Colors.White);
            page.DefaultTextStyle(x=>x.FontFamily("Lato").FontSize(9).FontColor(Colors.Grey.Darken4));
            page.Header().Column(header=>
            {
                header.Item().Text("CIVORA  |  CALCULATION REPORT").FontSize(18).Bold().FontColor("#10253B");
                header.Item().Text($"{Clean(projectName)}  •  Generated {DateTime.Now:yyyy-MM-dd HH:mm}").FontSize(9).FontColor("#536779");
            });
            page.Content().Column(column=>
            {
                column.Spacing(8);
                column.Item().Text("Saved calculation history").FontSize(12).Bold();
                if(history.Count==0)column.Item().Text("No calculations have been saved.");
                foreach(var item in history)
                    column.Item().Padding(7).BorderBottom(0.5f).BorderColor("#CBD5DF").Column(entry=>
                    {
                        entry.Item().Text($"{item.Created.ToLocalTime():yyyy-MM-dd HH:mm}  |  {Clean(item.Title)}").Bold().FontColor("#145D71");
                        entry.Item().PaddingTop(3).Text(Clean(item.Result)).FontSize(8);
                    });
                column.Item().PaddingTop(10).Text("PRELIMINARY ESTIMATE — DESIGN CODE NOT VERIFIED. Review calculation inputs, assumptions, limitations and local requirements before engineering use.").Bold().FontColor("#8B5D00");
            });
            page.Footer().AlignCenter().Text("CIVORA • Local calculation summary • Preliminary estimate").FontSize(8).FontColor("#536779");
        })).GeneratePdf(path);
    }

    private static string DrawingSvg(CivoraProject p,float width,float height)
    {
        var w=Math.Max(p.BuildingWidthM,.01);var h=Math.Max(p.BuildingDepthM,.01);var scale=Math.Min((width-60)/w,(height-60)/h);var ox=(width-w*scale)/2;var oy=(height+h*scale)/2;
        string N(double n)=>n.ToString("0.##",CultureInfo.InvariantCulture);var s=new StringBuilder();
        s.Append($"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{N(width)}\" height=\"{N(height)}\" viewBox=\"0 0 {N(width)} {N(height)}\"><rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/>");
        s.Append($"<rect x=\"{N(ox)}\" y=\"{N(oy-h*scale)}\" width=\"{N(w*scale)}\" height=\"{N(h*scale)}\" fill=\"none\" stroke=\"#344C65\" stroke-width=\"1.2\"/>");
        foreach(var x in p.Columns.Select(c=>Math.Round(c.X,3)).Distinct())s.Append($"<line x1=\"{N(ox+x*scale)}\" y1=\"{N(oy)}\" x2=\"{N(ox+x*scale)}\" y2=\"{N(oy-h*scale)}\" stroke=\"#9AA8B7\" stroke-width=\"0.55\" stroke-dasharray=\"4 4\"/>");
        foreach(var y in p.Columns.Select(c=>Math.Round(c.Y,3)).Distinct())s.Append($"<line x1=\"{N(ox)}\" y1=\"{N(oy-y*scale)}\" x2=\"{N(ox+w*scale)}\" y2=\"{N(oy-y*scale)}\" stroke=\"#9AA8B7\" stroke-width=\"0.55\" stroke-dasharray=\"4 4\"/>");
        foreach(var row in p.Columns.GroupBy(c=>Math.Round(c.Y,3))){var a=row.OrderBy(c=>c.X).ToArray();for(var i=1;i<a.Length;i++)s.Append($"<line x1=\"{N(ox+a[i-1].X*scale)}\" y1=\"{N(oy-a[i-1].Y*scale)}\" x2=\"{N(ox+a[i].X*scale)}\" y2=\"{N(oy-a[i].Y*scale)}\" stroke=\"#7857B8\" stroke-width=\"1.4\"/>");}
        foreach(var c in p.Columns){var x=ox+c.X*scale;var y=oy-c.Y*scale;var bw=Math.Clamp(c.WidthMm/1000*scale,4,18);var bh=Math.Clamp(c.DepthMm/1000*scale,4,18);s.Append($"<rect x=\"{N(x-bw/2)}\" y=\"{N(y-bh/2)}\" width=\"{N(bw)}\" height=\"{N(bh)}\" fill=\"#21C2C7\" stroke=\"#087F88\" stroke-width=\"0.8\"/><text x=\"{N(x+bw/2+3)}\" y=\"{N(y-2)}\" font-family=\"Lato\" font-size=\"8\" fill=\"#172A3D\">{SvgEscape(c.Id)}</text>");}
        s.Append("</svg>");return s.ToString();
    }

    private static string SvgEscape(string value)=>value.Replace("&","&amp;").Replace("<","&lt;").Replace(">","&gt;").Replace("\"","&quot;");
    private static string Clean(string s)=>s.Replace("\\","/").Replace("\r"," ").Replace("\n"," ");
    private static string N(double v)=>v.ToString("0.###",CultureInfo.InvariantCulture);
    private static void Line(StringBuilder s,double x1,double y1,double x2,double y2,string layer)=>s.Append($"0\nLINE\n8\n{layer}\n10\n{N(x1)}\n20\n{N(y1)}\n30\n0\n11\n{N(x2)}\n21\n{N(y2)}\n31\n0\n");
    private static void Text(StringBuilder s,double x,double y,double size,string text,string layer)=>s.Append($"0\nTEXT\n8\n{layer}\n10\n{N(x)}\n20\n{N(y)}\n30\n0\n40\n{N(size)}\n1\n{text.Replace("\n"," ")}\n");
}


