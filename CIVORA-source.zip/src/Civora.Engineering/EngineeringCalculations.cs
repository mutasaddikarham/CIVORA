using System.Globalization;

namespace Civora.Engineering;

public static class EngineeringCalculations
{
    private static double Positive(double value, string name)
    {
        if (!double.IsFinite(value) || value <= 0) throw new ArgumentOutOfRangeException(name, "Enter a finite value greater than zero.");
        return value;
    }
    private static double NonNegative(double value, string name)
    {
        if (!double.IsFinite(value) || value < 0) throw new ArgumentOutOfRangeException(name, "Enter a finite value of zero or greater.");
        return value;
    }
    private static string F(double value, string unit) => $"{value.ToString("0.####", CultureInfo.InvariantCulture)} {unit}";

    public static double CalibrateScale(double pixelDistance, double knownDistance, string unit = "m")
    {
        Positive(pixelDistance, nameof(pixelDistance)); Positive(knownDistance, nameof(knownDistance));
        var metres = unit.Trim().ToLowerInvariant() switch
        {
            "mm" or "millimeter" or "millimeters" => knownDistance / 1000,
            "cm" or "centimeter" or "centimeters" => knownDistance / 100,
            "m" or "meter" or "meters" => knownDistance,
            "in" or "inch" or "inches" => knownDistance * 0.0254,
            "ft" or "foot" or "feet" => knownDistance * 0.3048,
            _ => throw new ArgumentException("Supported calibration units are mm, cm, m, in and ft.", nameof(unit))
        };
        return metres / pixelDistance;
    }

    public static double Convert(double value, string from, string to)
    {
        if (!double.IsFinite(value)) throw new ArgumentOutOfRangeException(nameof(value), "Enter a finite value.");
        var a = from.Trim().ToLowerInvariant(); var b = to.Trim().ToLowerInvariant();
        if (a == b) return value;
        var lengths = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["mm"]=0.001,["cm"]=0.01,["m"]=1,["km"]=1000,["in"]=0.0254,["ft"]=0.3048,["yd"]=0.9144,["mi"]=1609.344 };
        var area = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["mm²"]=1e-6,["cm²"]=1e-4,["m²"]=1,["ha"]=10000,["km²"]=1e6,["in²"]=0.00064516,["ft²"]=0.09290304,["yd²"]=0.83612736,["acre"]=4046.8564224 };
        var volume = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["mm³"]=1e-9,["cm³"]=1e-6,["m³"]=1,["l"]=0.001,["ml"]=1e-6,["ft³"]=0.028316846592,["in³"]=0.000016387064 };
        var mass = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["mg"]=1e-6,["g"]=0.001,["kg"]=1,["t"]=1000,["lb"]=0.45359237,["oz"]=0.028349523125 };
        var force = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["n"]=0.001,["kn"]=1,["mn"]=1000,["kgf"]=0.00980665,["lbf"]=0.004448221615 };
        var pressure = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["pa"]=1e-6,["kpa"]=0.001,["mpa"]=1,["gpa"]=1000,["bar"]=0.1,["psi"]=0.006894757293,["ksi"]=6.894757293 };
        var density = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["kg/m³"]=1,["g/cm³"]=1000,["lb/ft³"]=16.01846337,["kN/m³"]=101.9716213 };
        var speed = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["m/s"]=1,["km/h"]=1/3.6,["ft/s"]=0.3048,["mph"]=0.44704 };
        var time = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["s"]=1,["min"]=60,["h"]=3600,["day"]=86400 };
        var flow = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase) { ["m³/s"]=1,["l/s"]=0.001,["l/min"]=1/60000.0,["m³/h"]=1/3600.0,["ft³/s"]=0.028316846592 };
        if (Try(lengths, value,a,b,out var result) || Try(area,value,a,b,out result) || Try(volume,value,a,b,out result) || Try(mass,value,a,b,out result) || Try(force,value,a,b,out result) || Try(pressure,value,a,b,out result) || Try(density,value,a,b,out result) || Try(speed,value,a,b,out result) || Try(time,value,a,b,out result) || Try(flow,value,a,b,out result)) return result;
        if (a is "deg" or "degree" && b is "rad" or "radian") return value * Math.PI / 180;
        if (a is "rad" or "radian" && b is "deg" or "degree") return value * 180 / Math.PI;
        if (a is "c" or "°c" && b is "f" or "°f") return value * 9 / 5 + 32;
        if (a is "f" or "°f" && b is "c" or "°c") return (value - 32) * 5 / 9;
        if (a is "c" or "°c" && b is "k") return value + 273.15;
        if (a is "k" && b is "c" or "°c") return value - 273.15;
        throw new ArgumentException($"Unsupported or incompatible unit conversion: {from} to {to}.");
    }
    private static bool Try(Dictionary<string,double> table,double value,string from,string to,out double result)
    {
        if (table.TryGetValue(from,out var a) && table.TryGetValue(to,out var b)) { result = value*a/b; return true; }
        result = 0; return false;
    }

    public static CalculationResult Scale(double drawingLength, double scaleRatio)
    {
        Positive(drawingLength,nameof(drawingLength)); Positive(scaleRatio,nameof(scaleRatio));
        var actual = drawingLength * scaleRatio;
        return new("Scale calculation","Actual length = drawing length × scale denominator",new Dictionary<string,string>{{"Drawing length",F(drawingLength,"mm")},{"Scale","1:"+scaleRatio.ToString("0.####",CultureInfo.InvariantCulture)}},[$"{drawingLength:0.####} × {scaleRatio:0.####} = {actual:0.####} mm"],F(actual,"mm"),"Assumes a stated ratio such as 1:100 and consistent drawing units.","Paper / screen distortion and printer scaling can change a printed scale.");
    }

    public static double RectangleArea(double width,double height) => Positive(width,nameof(width))*Positive(height,nameof(height));
    public static double TriangleArea(double @base,double height) => 0.5*Positive(@base,nameof(@base))*Positive(height,nameof(height));
    public static double CircleArea(double diameter) => Math.PI*Math.Pow(Positive(diameter,nameof(diameter))/2,2);
    public static double TrapezoidArea(double parallelA,double parallelB,double height) => (Positive(parallelA,nameof(parallelA))+Positive(parallelB,nameof(parallelB)))*Positive(height,nameof(height))/2;
    public static double PolygonArea(IReadOnlyList<(double X,double Y)> points)
    {
        if (points.Count < 3) throw new ArgumentException("A polygon needs at least three points.",nameof(points));
        double twice=0;
        for(var i=0;i<points.Count;i++){var a=points[i];var b=points[(i+1)%points.Count];if(!double.IsFinite(a.X)||!double.IsFinite(a.Y))throw new ArgumentException("Coordinates must be finite.");twice+=a.X*b.Y-b.X*a.Y;}
        return Math.Abs(twice)/2;
    }

    public static double ConcreteVolume(double length,double width,double thickness) => Positive(length,nameof(length))*Positive(width,nameof(width))*Positive(thickness,nameof(thickness));
    public static double StairWaistSlabVolume(double width,double waistThickness,double horizontalRun,double rise) => Positive(width,nameof(width))*Positive(waistThickness,nameof(waistThickness))*Math.Sqrt(Math.Pow(Positive(horizontalRun,nameof(horizontalRun)),2)+Math.Pow(NonNegative(rise,nameof(rise)),2));
    public static double BarWeightKgPerM(double diameterMm) => Math.Pow(Positive(diameterMm,nameof(diameterMm)),2)/162;
    public static double ReinforcementWeightKg(double diameterMm,double lengthM,double count) => BarWeightKgPerM(diameterMm)*Positive(lengthM,nameof(lengthM))*Positive(count,nameof(count));
    public static int BarsForSpacing(double clearLengthMm,double spacingMm) => (int)Math.Ceiling(Positive(clearLengthMm,nameof(clearLengthMm))/Positive(spacingMm,nameof(spacingMm)))+1;

    public static (double CementKg,double SandM3,double AggregateM3) EstimateConcreteMaterials(double wetVolumeM3,double cementParts=1,double sandParts=2,double aggregateParts=4,double dryFactor=1.54,double cementDensityKgM3=1440,double sandDensityKgM3=1600,double aggregateDensityKgM3=1500)
    {
        Positive(wetVolumeM3,nameof(wetVolumeM3)); Positive(cementParts,nameof(cementParts)); NonNegative(sandParts,nameof(sandParts)); NonNegative(aggregateParts,nameof(aggregateParts)); Positive(dryFactor,nameof(dryFactor)); Positive(cementDensityKgM3,nameof(cementDensityKgM3)); Positive(sandDensityKgM3,nameof(sandDensityKgM3)); Positive(aggregateDensityKgM3,nameof(aggregateDensityKgM3));
        var total=cementParts+sandParts+aggregateParts;if(total<=0)throw new ArgumentException("Mix proportions must sum to more than zero.");
        var dry=wetVolumeM3*dryFactor;
        return (dry*cementParts/total*cementDensityKgM3,dry*sandParts/total,dry*aggregateParts/total);
    }

    public static BeamResult SimplySupportedUniform(double loadKnPerM,double spanM)
    {
        var w=NonNegative(loadKnPerM,nameof(loadKnPerM));var l=Positive(spanM,nameof(spanM));
        return new(w*l/2,w*l/2,w*l*l/8,w*l/2);
    }
    public static BeamResult SimplySupportedPoint(double pointLoadKn,double spanM,double distanceFromLeftM)
    {
        var p=NonNegative(pointLoadKn,nameof(pointLoadKn));var l=Positive(spanM,nameof(spanM));if(!double.IsFinite(distanceFromLeftM)||distanceFromLeftM<0||distanceFromLeftM>l)throw new ArgumentOutOfRangeException(nameof(distanceFromLeftM),"Load position must be between the supports.");
        var b=l-distanceFromLeftM;var rL=p*b/l;var rR=p*distanceFromLeftM/l;return new(rL,rR,rL*distanceFromLeftM,Math.Max(rL,rR));
    }
    public static BeamResult CantileverPoint(double pointLoadKn,double lengthM) {var p=NonNegative(pointLoadKn,nameof(pointLoadKn));var l=Positive(lengthM,nameof(lengthM));return new(p,0,p*l,p);}
    public static BeamResult CantileverUniform(double loadKnPerM,double lengthM) {var w=NonNegative(loadKnPerM,nameof(loadKnPerM));var l=Positive(lengthM,nameof(lengthM));return new(w*l,0,w*l*l/2,w*l);}

    public static (double AreaM2,double StressMpa) ColumnAverageStress(double widthMm,double depthMm,double axialLoadKn)
    {
        var b=Positive(widthMm,nameof(widthMm));var h=Positive(depthMm,nameof(depthMm));var p=NonNegative(axialLoadKn,nameof(axialLoadKn));var area=b*h/1e6;var stress=p*1000/(b*h);return(area,stress);
    }
    public static (double AreaM2,double BearingPressureKpa) FootingBearing(double serviceLoadKn,double footingLengthM,double footingWidthM)
    {
        var p=NonNegative(serviceLoadKn,nameof(serviceLoadKn));var l=Positive(footingLengthM,nameof(footingLengthM));var b=Positive(footingWidthM,nameof(footingWidthM));var area=l*b;return(area,p/area);
    }

    public static (double NetVolumeM3,double BrickCount,double MortarVolumeM3) Brickwork(double wallLengthM,double wallHeightM,double wallThicknessM,double openingAreaM2,double brickLengthMm,double brickWidthMm,double brickHeightMm,double jointMm=10)
    {
        var wall=Positive(wallLengthM,nameof(wallLengthM))*Positive(wallHeightM,nameof(wallHeightM));var openings=NonNegative(openingAreaM2,nameof(openingAreaM2));if(openings>=wall)throw new ArgumentOutOfRangeException(nameof(openingAreaM2),"Opening area must be less than gross wall area.");
        var volume=(wall-openings)*Positive(wallThicknessM,nameof(wallThicknessM));var unitVolume=Math.Pow((Positive(brickLengthMm,nameof(brickLengthMm))+jointMm)/1000,1)*((brickWidthMm+jointMm)/1000)*((brickHeightMm+jointMm)/1000);if(brickWidthMm<=0||brickHeightMm<=0||jointMm<0)throw new ArgumentOutOfRangeException(nameof(brickWidthMm));
        var count=volume/unitVolume;var solidBrick= count*(brickLengthMm/1000)*(brickWidthMm/1000)*(brickHeightMm/1000);return(volume,count,Math.Max(0,volume-solidBrick));
    }
    public static double CoordinateDistance(double x1,double y1,double x2,double y2)=>Math.Sqrt(Math.Pow(x2-x1,2)+Math.Pow(y2-y1,2));
    public static double GradientPercent(double rise,double horizontalRun)=>NonNegative(Math.Abs(rise),nameof(rise))/Positive(horizontalRun,nameof(horizontalRun))*100;
    public static double ReducedLevelFromHeightOfInstrument(double benchmarkRl,double backsight,double foresight)=>benchmarkRl+backsight-foresight;
    public static double LineLoadFromAreaLoad(double areaLoadKnM2,double tributaryWidthM)=>NonNegative(areaLoadKnM2,nameof(areaLoadKnM2))*Positive(tributaryWidthM,nameof(tributaryWidthM));

    public static IReadOnlyList<StructuralColumn> GenerateGrid(double widthM,double depthM,double maximumSpanM,double sectionWidthMm=300,double sectionDepthMm=300)
    {
        var w=Positive(widthM,nameof(widthM));var d=Positive(depthM,nameof(depthM));var span=Positive(maximumSpanM,nameof(maximumSpanM));
        var nx=Math.Max(1,(int)Math.Ceiling(w/span));var ny=Math.Max(1,(int)Math.Ceiling(d/span));var columns=new List<StructuralColumn>();var n=1;
        for(var iy=0;iy<=ny;iy++)for(var ix=0;ix<=nx;ix++)
        {
            var spans=new List<string>();
            if(ix>0)spans.Add($"L {w/nx:0.##} m");if(ix<nx)spans.Add($"R {w/nx:0.##} m");
            if(iy>0)spans.Add($"D {d/ny:0.##} m");if(iy<ny)spans.Add($"U {d/ny:0.##} m");
            columns.Add(new(){Id=$"C{n++}",X=w*ix/nx,Y=d*iy/ny,WidthMm=Positive(sectionWidthMm,nameof(sectionWidthMm)),DepthMm=Positive(sectionDepthMm,nameof(sectionDepthMm)),Notes="Uniform grid point from entered footprint and preliminary maximum span.",CandidateReason="Building-edge / preliminary grid intersection generated from the entered rectangular footprint.",AdjacentSpans=string.Join("; ",spans),ArchitecturalConflicts="Not assessed — walls, openings, circulation, shafts and stairs are not detected.",MissingDesignInformation="Confirm floors, occupancy, structural system, loads, materials, soil and design code.",Confidence="Low — conceptual grid only",ReviewStatus="Candidate — review required"});
        }
        return columns;
    }
}


