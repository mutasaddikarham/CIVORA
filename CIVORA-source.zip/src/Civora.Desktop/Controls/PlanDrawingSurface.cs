using System.Collections.Specialized;
using System.ComponentModel;
using System.IO;
using System.Collections;
using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Civora.Engineering;

namespace Civora.Desktop.Controls;

public sealed record ColumnMove(StructuralColumn Column,double X,double Y);

public sealed class PlanDrawingSurface : FrameworkElement
{
    public static readonly DependencyProperty PlanImageProperty=DependencyProperty.Register(nameof(PlanImage),typeof(BitmapSource),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(null,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty ColumnsProperty=DependencyProperty.Register(nameof(Columns),typeof(IEnumerable),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(null,FrameworkPropertyMetadataOptions.AffectsRender,ColumnsChanged));
    public static readonly DependencyProperty MetresPerPixelProperty=DependencyProperty.Register(nameof(MetresPerPixel),typeof(double),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(double.NaN,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty OriginPixelXProperty=DependencyProperty.Register(nameof(OriginPixelX),typeof(double),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(double.NaN,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty OriginPixelYProperty=DependencyProperty.Register(nameof(OriginPixelY),typeof(double),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(double.NaN,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty BuildingWidthMProperty=DependencyProperty.Register(nameof(BuildingWidthM),typeof(double),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(12d,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty BuildingDepthMProperty=DependencyProperty.Register(nameof(BuildingDepthM),typeof(double),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata(9d,FrameworkPropertyMetadataOptions.AffectsRender));
    public static readonly DependencyProperty InteractionModeProperty=DependencyProperty.Register(nameof(InteractionMode),typeof(string),typeof(PlanDrawingSurface),new FrameworkPropertyMetadata("Select"));
    public static readonly DependencyProperty PointClickedCommandProperty=DependencyProperty.Register(nameof(PointClickedCommand),typeof(ICommand),typeof(PlanDrawingSurface));
    public static readonly DependencyProperty ColumnMovedCommandProperty=DependencyProperty.Register(nameof(ColumnMovedCommand),typeof(ICommand),typeof(PlanDrawingSurface));

    public BitmapSource? PlanImage {get=>(BitmapSource?)GetValue(PlanImageProperty);set=>SetValue(PlanImageProperty,value);}
    public IEnumerable? Columns {get=>(IEnumerable?)GetValue(ColumnsProperty);set=>SetValue(ColumnsProperty,value);}
    public double MetresPerPixel {get=>(double)GetValue(MetresPerPixelProperty);set=>SetValue(MetresPerPixelProperty,value);}
    public double OriginPixelX {get=>(double)GetValue(OriginPixelXProperty);set=>SetValue(OriginPixelXProperty,value);}
    public double OriginPixelY {get=>(double)GetValue(OriginPixelYProperty);set=>SetValue(OriginPixelYProperty,value);}
    public double BuildingWidthM {get=>(double)GetValue(BuildingWidthMProperty);set=>SetValue(BuildingWidthMProperty,value);}
    public double BuildingDepthM {get=>(double)GetValue(BuildingDepthMProperty);set=>SetValue(BuildingDepthMProperty,value);}
    public string InteractionMode {get=>(string)GetValue(InteractionModeProperty);set=>SetValue(InteractionModeProperty,value);}
    public ICommand? PointClickedCommand {get=>(ICommand?)GetValue(PointClickedCommandProperty);set=>SetValue(PointClickedCommandProperty,value);}
    public ICommand? ColumnMovedCommand {get=>(ICommand?)GetValue(ColumnMovedCommandProperty);set=>SetValue(ColumnMovedCommandProperty,value);}

    private StructuralColumn? _drag;
    private IEnumerable? _watchedColumns;
    private static void ColumnsChanged(DependencyObject d,DependencyPropertyChangedEventArgs e){if(d is not PlanDrawingSurface s)return;if(s._watchedColumns is INotifyCollectionChanged oldCollection)oldCollection.CollectionChanged-=s.OnCollectionChanged;s.UnsubscribeItems(s._watchedColumns);s._watchedColumns=e.NewValue as IEnumerable;if(s._watchedColumns is INotifyCollectionChanged newCollection)newCollection.CollectionChanged+=s.OnCollectionChanged;s.SubscribeItems(s._watchedColumns);s.InvalidateVisual();}
    private void OnCollectionChanged(object? sender,NotifyCollectionChangedEventArgs e){UnsubscribeItems(_watchedColumns);SubscribeItems(_watchedColumns);InvalidateVisual();}
    private void SubscribeItems(IEnumerable? source){if(source is null)return;foreach(var item in source)if(item is INotifyPropertyChanged n)n.PropertyChanged+=OnColumnPropertyChanged;}
    private void UnsubscribeItems(IEnumerable? source){if(source is null)return;foreach(var item in source)if(item is INotifyPropertyChanged n)n.PropertyChanged-=OnColumnPropertyChanged;}
    private void OnColumnPropertyChanged(object? sender,PropertyChangedEventArgs e)=>InvalidateVisual();
    private readonly Brush _gridBrush=new SolidColorBrush(Color.FromArgb(45,112,147,182));
    private static readonly Brush Cyan=new SolidColorBrush(Color.FromRgb(38,224,231));
    private static readonly Brush Violet=new SolidColorBrush(Color.FromRgb(156,126,255));
    private static readonly Brush TextBrush=new SolidColorBrush(Color.FromRgb(224,235,247));

    public PlanDrawingSurface(){Focusable=true;ClipToBounds=true;SnapsToDevicePixels=true;MouseLeftButtonDown+=Down;MouseMove+=Move;MouseLeftButtonUp+=Up;}

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);dc.DrawRectangle(new SolidColorBrush(Color.FromRgb(12,20,34)),null,new Rect(0,0,ActualWidth,ActualHeight));
        if(ActualWidth<20||ActualHeight<20)return;
        var size=PlanImage is null?new Size(0,0):new Size(PlanImage.PixelWidth,PlanImage.PixelHeight);var tr=TransformFor(size);
        if(PlanImage is not null)dc.DrawImage(PlanImage,new Rect(tr.X,tr.Y,size.Width*tr.Scale,size.Height*tr.Scale));else DrawGridBackground(dc);
        var columns=ReadColumns();if(columns.Count==0)return;
        foreach(var row in columns.GroupBy(c=>Math.Round(c.Y,3))){var a=row.OrderBy(c=>c.X).ToArray();for(var i=1;i<a.Length;i++)dc.DrawLine(new Pen(Violet,2),WorldToScreen(a[i-1].X,a[i-1].Y,size,tr),WorldToScreen(a[i].X,a[i].Y,size,tr));}
        foreach(var c in columns){var center=WorldToScreen(c.X,c.Y,size,tr);var factor=PixelScale(size,tr);var w=Math.Clamp(c.WidthMm/1000*factor,7,36);var h=Math.Clamp(c.DepthMm/1000*factor,7,36);dc.DrawRectangle(new SolidColorBrush(Color.FromArgb(220,20,191,202)),new Pen(Cyan,1.5),new Rect(center.X-w/2,center.Y-h/2,w,h));var label=new FormattedText(c.Id,CultureInfo.InvariantCulture,FlowDirection.LeftToRight,new Typeface("Segoe UI Semibold"),11,TextBrush,VisualTreeHelper.GetDpi(this).PixelsPerDip);dc.DrawText(label,new Point(center.X+7,center.Y+4));}
        if(double.IsFinite(OriginPixelX)&&double.IsFinite(OriginPixelY)&&PlanImage is not null)dc.DrawEllipse(Cyan,new Pen(Brushes.Black,1),ImageToScreen(new Point(OriginPixelX,OriginPixelY),tr),5,5);
        if(double.IsFinite(MetresPerPixel)&&MetresPerPixel>0&&PlanImage is not null){var p=ImageToScreen(new Point(18,22),tr);dc.DrawLine(new Pen(Cyan,3),p,new Point(p.X+Math.Min(100,1/MetresPerPixel*tr.Scale),p.Y));}
    }

    private void DrawGridBackground(DrawingContext dc)
    {
        var w=Math.Max(BuildingWidthM,1);var h=Math.Max(BuildingDepthM,1);var scale=Math.Min((ActualWidth-80)/w,(ActualHeight-80)/h);var ox=(ActualWidth-w*scale)/2;var oy=(ActualHeight+h*scale)/2;
        for(var x=0d;x<=w;x+=Math.Max(1,Math.Ceiling(w/12)))dc.DrawLine(new Pen(_gridBrush,1),new Point(ox+x*scale,oy),new Point(ox+x*scale,oy-h*scale));
        for(var y=0d;y<=h;y+=Math.Max(1,Math.Ceiling(h/12)))dc.DrawLine(new Pen(_gridBrush,1),new Point(ox,oy-y*scale),new Point(ox+w*scale,oy-y*scale));
        dc.DrawRectangle(null,new Pen(Cyan,1),new Rect(ox,oy-h*scale,w*scale,h*scale));
        dc.DrawText(new FormattedText("STRUCTURAL OVERLAY • SET DIMENSIONS + GENERATE A CONCEPTUAL GRID",CultureInfo.InvariantCulture,FlowDirection.LeftToRight,new Typeface("Segoe UI"),12,TextBrush,VisualTreeHelper.GetDpi(this).PixelsPerDip),new Point(18,18));
    }

    private (double X,double Y,double Scale) TransformFor(Size size)
    {if(PlanImage is null||size.Width<=0||size.Height<=0)return(0,0,1);var s=Math.Min(Math.Max(0,ActualWidth-30)/size.Width,Math.Max(0,ActualHeight-30)/size.Height);return((ActualWidth-size.Width*s)/2,(ActualHeight-size.Height*s)/2,s);}
    private Point ImageToScreen(Point p,(double X,double Y,double Scale)t)=>new(t.X+p.X*t.Scale,t.Y+p.Y*t.Scale);
    private Point ScreenToImage(Point p,(double X,double Y,double Scale)t)=>new((p.X-t.X)/t.Scale,(p.Y-t.Y)/t.Scale);
    private Point WorldToImage(double x,double y,Size s)=>double.IsFinite(MetresPerPixel)&&MetresPerPixel>0?new((double.IsFinite(OriginPixelX)?OriginPixelX:0)+x/MetresPerPixel,(double.IsFinite(OriginPixelY)?OriginPixelY:s.Height)-y/MetresPerPixel):new(x/Math.Max(BuildingWidthM,.01)*s.Width,s.Height-y/Math.Max(BuildingDepthM,.01)*s.Height);
    private (double X,double Y) ImageToWorld(Point p,Size s)=>double.IsFinite(MetresPerPixel)&&MetresPerPixel>0?((p.X-(double.IsFinite(OriginPixelX)?OriginPixelX:0))*MetresPerPixel,((double.IsFinite(OriginPixelY)?OriginPixelY:s.Height)-p.Y)*MetresPerPixel):(p.X/s.Width*Math.Max(BuildingWidthM,.01),(s.Height-p.Y)/s.Height*Math.Max(BuildingDepthM,.01));
    private Point WorldToScreen(double x,double y,Size s,(double X,double Y,double Scale)t)=>PlanImage is null?GridToScreen(x,y):ImageToScreen(WorldToImage(x,y,s),t);
    private Point GridToScreen(double x,double y){var sc=Math.Min((ActualWidth-80)/Math.Max(BuildingWidthM,1),(ActualHeight-80)/Math.Max(BuildingDepthM,1));var ox=(ActualWidth-BuildingWidthM*sc)/2;var oy=(ActualHeight+BuildingDepthM*sc)/2;return new(ox+x*sc,oy-y*sc);}
    private double PixelScale(Size s,(double X,double Y,double Scale)t)=>PlanImage is null?Math.Min((ActualWidth-80)/Math.Max(BuildingWidthM,1),(ActualHeight-80)/Math.Max(BuildingDepthM,1)):t.Scale/(double.IsFinite(MetresPerPixel)&&MetresPerPixel>0?MetresPerPixel:Math.Max(BuildingWidthM,.01)/s.Width);
    private List<StructuralColumn> ReadColumns(){var result=new List<StructuralColumn>();if(Columns is not null)foreach(var v in Columns)if(v is StructuralColumn c)result.Add(c);return result;}

    private void Down(object sender,MouseButtonEventArgs e)
    {
        Focus();var p=e.GetPosition(this);var size=PlanImage is null?new Size(Math.Max(BuildingWidthM,1),Math.Max(BuildingDepthM,1)):new Size(PlanImage.PixelWidth,PlanImage.PixelHeight);var tr=TransformFor(size);
        if(InteractionMode is "Calibrate" or "Origin" or "AddColumn"){PointClickedCommand?.Execute(PlanImage is null?new Point(GridToWorld(p).X,GridToWorld(p).Y):ScreenToImage(p,tr));e.Handled=true;return;}
        _drag=ReadColumns().OrderBy(c=>(WorldToScreen(c.X,c.Y,size,tr)-p).Length).FirstOrDefault(c=>(WorldToScreen(c.X,c.Y,size,tr)-p).Length<18);
        if(_drag is not null){CaptureMouse();e.Handled=true;}
    }
    private void Move(object sender,MouseEventArgs e)
    {
        if(_drag is null||e.LeftButton!=MouseButtonState.Pressed)return;var p=e.GetPosition(this);var size=PlanImage is null?new Size(Math.Max(BuildingWidthM,1),Math.Max(BuildingDepthM,1)):new Size(PlanImage.PixelWidth,PlanImage.PixelHeight);var tr=TransformFor(size);var world=PlanImage is null?GridToWorld(p):ImageToWorld(ScreenToImage(p,tr),size);ColumnMovedCommand?.Execute(new ColumnMove(_drag,world.X,world.Y));e.Handled=true;
    }
    private (double X,double Y) GridToWorld(Point p){var sc=Math.Min((ActualWidth-80)/Math.Max(BuildingWidthM,1),(ActualHeight-80)/Math.Max(BuildingDepthM,1));var ox=(ActualWidth-BuildingWidthM*sc)/2;var oy=(ActualHeight+BuildingDepthM*sc)/2;return(Math.Clamp((p.X-ox)/sc,0,BuildingWidthM),Math.Clamp((oy-p.Y)/sc,0,BuildingDepthM));}
    private void Up(object sender,MouseButtonEventArgs e){if(_drag is not null){_drag=null;ReleaseMouseCapture();e.Handled=true;}}

    public void ExportPng(string path){if(ActualWidth<1||ActualHeight<1)throw new InvalidOperationException("Drawing surface is not visible.");var bitmap=new RenderTargetBitmap((int)Math.Ceiling(ActualWidth),(int)Math.Ceiling(ActualHeight),96,96,PixelFormats.Pbgra32);bitmap.Render(this);var enc=new PngBitmapEncoder();enc.Frames.Add(BitmapFrame.Create(bitmap));using var file=File.Create(path);enc.Save(file);}
}




