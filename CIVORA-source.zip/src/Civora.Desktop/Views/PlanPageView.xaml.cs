using System.Windows;
using System.Windows.Controls;
using Civora.Desktop.ViewModels;

namespace Civora.Desktop.Views;

public partial class PlanPageView : UserControl
{
    public PlanPageView(){InitializeComponent();}
    private void ExportPng_Click(object sender,RoutedEventArgs e){if(DataContext is PlanPageViewModel vm)vm.ExportPng(DrawingSurface);}
}
