using System.Windows.Controls;

namespace Civora.Desktop.Views;

public partial class DashboardView : UserControl { public DashboardView(){InitializeComponent();} }
public partial class CalculatorPageView : UserControl { public CalculatorPageView(){InitializeComponent();} }
public partial class DefaultsPageView : UserControl { public DefaultsPageView(){InitializeComponent();} }
public partial class ProjectsPageView : UserControl { public ProjectsPageView(){InitializeComponent();} }
public partial class SchedulePageView : UserControl { public SchedulePageView(){InitializeComponent();} }
public partial class HistoryPageView : UserControl { public HistoryPageView(){InitializeComponent();} }
public partial class ReportsPageView : UserControl { public ReportsPageView(){InitializeComponent();} }
public partial class AboutPageView : UserControl { public AboutPageView(){InitializeComponent();} }

