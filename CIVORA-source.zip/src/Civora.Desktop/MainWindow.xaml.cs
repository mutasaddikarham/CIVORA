using System.Windows;
using Civora.Desktop.ViewModels;

namespace Civora.Desktop;

public partial class MainWindow : Window
{
    public MainWindow(){InitializeComponent();DataContext=new MainViewModel();}
}
