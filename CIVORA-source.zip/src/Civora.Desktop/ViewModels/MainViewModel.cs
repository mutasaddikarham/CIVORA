using System.Collections.ObjectModel;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Civora.Engineering;
using Civora.Desktop.Views;

namespace Civora.Desktop.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private object _currentPage;
    private string _currentTitle="Dashboard";
    private CivoraProject _project=new();private string _persistedProjectName="";
    public ProjectRepository Repository {get;}
    public ObservableCollection<string> NavigationItems {get;}=[];
    public DashboardViewModel Dashboard {get;}
    public object CurrentPage {get=>_currentPage;private set=>SetProperty(ref _currentPage,value);}
    public string CurrentTitle {get=>_currentTitle;private set=>SetProperty(ref _currentTitle,value);}
    public CivoraProject Project {get=>_project;private set=>SetProperty(ref _project,value);}
    public string ProjectName=>Project.Name;
    public string StatusMessage {get;private set;}="Local workspace ready";
    public IRelayCommand<string> NavigateCommand {get;}
    public IRelayCommand CreateProjectCommand {get;}

    public MainViewModel()
    {
        Repository=new ProjectRepository();
        var first=Repository.ListProjects().FirstOrDefault();
        Project=first.Name is null?new CivoraProject():Repository.LoadProject(first.Name)??new CivoraProject();_persistedProjectName=Project.Name;
        Dashboard=new DashboardViewModel(Repository,Navigate);
        _currentPage=Dashboard;
        NavigationItems=["Dashboard","AI Plan Analyzer","Column Layout Assistant","Structural Drawing Workspace","Scale Calculator","Unit Converter","Geometry & Area","Concrete & Materials","Structural Loads","Beam Analysis","Column Analysis","Foundation Calculator","Reinforcement Calculator","Brickwork Calculator","Surveying Tools","Material Library","Project Workspace","Column Schedule","Calculation History","Reports","Settings","About CIVORA"];
        NavigateCommand=new RelayCommand<string>(Navigate);
        CreateProjectCommand=new RelayCommand(CreateProject);
    }

    private void CreateProject(){Project=new CivoraProject{Name="New project",DrawingTitle="Structural concept plan"};_persistedProjectName=Project.Name;OnPropertyChanged(nameof(ProjectName));Navigate("Project Workspace");}
    public void SetProject(CivoraProject project){if(ReferenceEquals(Project,project)&&!string.Equals(_persistedProjectName,project.Name,StringComparison.OrdinalIgnoreCase)&&Repository.LoadProject(_persistedProjectName) is not null)Repository.RenameProject(_persistedProjectName,project.Name,project);else Repository.SaveProject(project);Project=project;_persistedProjectName=project.Name;OnPropertyChanged(nameof(ProjectName));}

    private void Navigate(string? route)
    {
        if(string.IsNullOrWhiteSpace(route))return;
        CurrentTitle=route;
        CurrentPage=route switch
        {
            "Dashboard"=>Dashboard,
            "AI Plan Analyzer" or "Column Layout Assistant" or "Structural Drawing Workspace"=>new PlanPageViewModel(Project,Repository,SetProject,route),
            "Material Library" or "Settings"=>new DefaultsPageViewModel(Repository,Project,SetProject,route),
            "Project Workspace"=>new ProjectsPageViewModel(Repository,Project,SetProject,Navigate),
            "Column Schedule"=>new SchedulePageViewModel(Project,Repository),
            "Calculation History"=>new HistoryPageViewModel(Repository,Project.Name),
            "Reports"=>new ReportsPageViewModel(Repository,Project),
            "About CIVORA"=>new AboutPageViewModel(),
            _=>new CalculatorPageViewModel(route,Project,Repository)
        };
    }
}

public sealed class DashboardViewModel : ObservableObject
{
    private readonly ProjectRepository _repo;private readonly Action<string> _navigate;
    public string Tagline=>"Calculate Smarter. Design Better. Build the Future.";
    public string BuilderCredit=>"Built by Er. Md Mutasaddik Arham";
    public int ProjectCount=>_repo.ListProjects().Count;
    public int DefaultCount=>_repo.GetEffectiveDefaults().Count;
    public string PreliminaryNotice=>"PRELIMINARY ESTIMATE — DESIGN CODE NOT VERIFIED";
    public IReadOnlyList<string> RecentProjects=>_repo.ListProjects().Take(4).Select(p=>$"{p.Name}  ·  {p.Modified:g}").ToList();
    public IRelayCommand<string> OpenCommand {get;}
    public IRelayCommand SaveProjectCommand {get;}
    private readonly Action _save;
    public DashboardViewModel(ProjectRepository repo,Action<string> navigate){_repo=repo;_navigate=navigate;_save=()=>{};OpenCommand=new RelayCommand<string>(s=>_navigate(s??"AI Plan Analyzer"));SaveProjectCommand=new RelayCommand(()=>_navigate("Project Workspace"));}
}






