using System.IO;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using System.Windows.Media.Imaging;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using Civora.Engineering;
using Civora.Desktop.Controls;

namespace Civora.Desktop.ViewModels;

public sealed class PlanPageViewModel : ObservableObject
{
    private readonly CivoraProject _project;private readonly ProjectRepository _repository;private readonly Action<CivoraProject> _save;private Point? _firstPoint;private Point? _secondPoint;
    private BitmapSource? _planImage;private string _interactionMode="Select";private string _status="Import a plan image, calibrate its scale and set the plan origin before placing a layout.";private string _knownDistanceText="5";private string _calibrationUnit="m";private string _widthText;private string _depthText;private string _spanText;private string _sectionWidthText="300";private string _sectionDepthText="300";private string _projectName;private string _drawingTitle;private string _floorCountText;private string _buildingUse;
    public string PageTitle {get;}
    public ObservableCollection<StructuralColumn> Columns {get;}=[];
    public IReadOnlyList<string> DistanceUnits {get;}=["mm","cm","m","in","ft"];
    public BitmapSource? PlanImage {get=>_planImage;private set=>SetProperty(ref _planImage,value);}
    public string InteractionMode {get=>_interactionMode;private set=>SetProperty(ref _interactionMode,value);}
    public string Status {get=>_status;private set=>SetProperty(ref _status,value);}
    public string KnownDistanceText {get=>_knownDistanceText;set=>SetProperty(ref _knownDistanceText,value);}
    public string CalibrationUnit {get=>_calibrationUnit;set=>SetProperty(ref _calibrationUnit,value);}
    public string WidthText {get=>_widthText;set{if(SetProperty(ref _widthText,value)&&Try(value,out var n)){_project.BuildingWidthM=n;OnPropertyChanged(nameof(BuildingWidthM));}}}
    public string DepthText {get=>_depthText;set{if(SetProperty(ref _depthText,value)&&Try(value,out var n)){_project.BuildingDepthM=n;OnPropertyChanged(nameof(BuildingDepthM));}}}
    public string SpanText {get=>_spanText;set{if(SetProperty(ref _spanText,value)&&Try(value,out var n)){_project.MaximumSpanM=n;}}}
    public string SectionWidthText {get=>_sectionWidthText;set=>SetProperty(ref _sectionWidthText,value);}
    public string SectionDepthText {get=>_sectionDepthText;set=>SetProperty(ref _sectionDepthText,value);}
    public string ProjectName {get=>_projectName;set{if(SetProperty(ref _projectName,value))_project.Name=value;}}
    public string DrawingTitle {get=>_drawingTitle;set{if(SetProperty(ref _drawingTitle,value))_project.DrawingTitle=value;}}
    public string FloorCountText {get=>_floorCountText;set{if(SetProperty(ref _floorCountText,value)){if(string.IsNullOrWhiteSpace(value))_project.FloorCount=0;else if(int.TryParse(value,out var n)&&n>0)_project.FloorCount=n;}}}
    public string BuildingUse {get=>_buildingUse;set{if(SetProperty(ref _buildingUse,value))_project.BuildingUse=value;}}
    public double MetresPerPixel=>_project.MetresPerPixel??double.NaN;
    public double OriginPixelX=>_project.CalibrationOriginXPixel??double.NaN;
    public double OriginPixelY=>_project.CalibrationOriginYPixel??double.NaN;
    public double BuildingWidthM=>_project.BuildingWidthM;
    public double BuildingDepthM=>_project.BuildingDepthM;
    public string CalibrationStatus=>_project.MetresPerPixel is double m?$"CALIBRATED • {m:0.######} m/pixel • verify against another known dimension":"SCALE UNKNOWN • use two known points before treating pixel measurements as real dimensions";
    public string PlanFileName=>string.IsNullOrWhiteSpace(_project.ImagePath)?"No plan image imported":Path.GetFileName(_project.ImagePath);
    public string Limitations=>"Raster plans only (PNG, JPG, TIFF, BMP, GIF). PDF page rendering, OCR / automatic object detection, crop, rotate and contrast controls are not implemented; use the manual geometry tools.";
    public IRelayCommand ImportPlanCommand {get;}
    public IRelayCommand BeginCalibrationCommand {get;}
    public IRelayCommand ApplyCalibrationCommand {get;}
    public IRelayCommand PickOriginCommand {get;}
    public IRelayCommand AddColumnCommand {get;}
    public IRelayCommand GenerateLayoutCommand {get;}
    public IRelayCommand SaveProjectCommand {get;}
    public IRelayCommand ExportDxfCommand {get;}
    public IRelayCommand ExportPdfCommand {get;}
    public IRelayCommand ExportCsvCommand {get;}
    public IRelayCommand ExportJsonCommand {get;}

    public PlanPageViewModel(CivoraProject project,ProjectRepository repository,Action<CivoraProject> save,string pageTitle)
    {
        _project=project;_repository=repository;_save=save;PageTitle=pageTitle;_widthText=project.BuildingWidthM.ToString(CultureInfo.InvariantCulture);_depthText=project.BuildingDepthM.ToString(CultureInfo.InvariantCulture);_spanText=project.MaximumSpanM.ToString(CultureInfo.InvariantCulture);_projectName=project.Name;_drawingTitle=project.DrawingTitle;_floorCountText=project.FloorCount>0?project.FloorCount.ToString(CultureInfo.InvariantCulture):"";_buildingUse=project.BuildingUse;
        foreach(var c in project.Columns)Columns.Add(c);
        LoadImageIfPresent();
        ImportPlanCommand=new RelayCommand(ImportPlan);BeginCalibrationCommand=new RelayCommand(BeginCalibration);ApplyCalibrationCommand=new RelayCommand(ApplyCalibration);PickOriginCommand=new RelayCommand(()=>{InteractionMode="Origin";Status="Click the lower-left structural origin in the plan. The calibration orientation is assumed horizontal / vertical.";} );
        AddColumnCommand=new RelayCommand(()=>{InteractionMode="AddColumn";Status="Click a location on the drawing to add a preliminary candidate. Drag candidate symbols to move them.";} );
        GenerateLayoutCommand=new RelayCommand(GenerateLayout);SaveProjectCommand=new RelayCommand(SaveProject);ExportDxfCommand=new RelayCommand(ExportDxf);ExportPdfCommand=new RelayCommand(ExportPdf);ExportCsvCommand=new RelayCommand(ExportCsv);ExportJsonCommand=new RelayCommand(ExportJson);
        PointClickedCommand=new RelayCommand<Point>(HandlePoint);ColumnMovedCommand=new RelayCommand<ColumnMove>(MoveColumn);
    }

    public IRelayCommand<Point> PointClickedCommand {get;}
    public IRelayCommand<ColumnMove> ColumnMovedCommand {get;}

    private void LoadImageIfPresent()
    {
        if(string.IsNullOrWhiteSpace(_project.ImagePath)||!File.Exists(_project.ImagePath))return;
        try{PlanImage=ReadBitmap(_project.ImagePath);}catch(Exception ex){Status=$"Could not load saved image: {ex.Message}";}
    }
    private static BitmapImage ReadBitmap(string path){var bitmap=new BitmapImage();bitmap.BeginInit();bitmap.CacheOption=BitmapCacheOption.OnLoad;bitmap.UriSource=new Uri(path);bitmap.EndInit();bitmap.Freeze();return bitmap;}
    private void ImportPlan()
    {
        var d=new OpenFileDialog{Title="Import an architectural plan image",Filter="Plan raster images|*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.bmp;*.gif|All files|*.*"};
        if(d.ShowDialog()!=true)return;
        try{var image=ReadBitmap(d.FileName);PlanImage=image;_project.ImagePath=d.FileName;_project.MetresPerPixel=null;_project.CalibrationPixelDistance=null;_project.CalibrationKnownMetres=null;_project.CalibrationOriginXPixel=null;_project.CalibrationOriginYPixel=null;OnPropertyChanged(nameof(MetresPerPixel));OnPropertyChanged(nameof(OriginPixelX));OnPropertyChanged(nameof(OriginPixelY));OnPropertyChanged(nameof(CalibrationStatus));OnPropertyChanged(nameof(PlanFileName));Status="Original image is preserved at its source path. Calibration was cleared because a new source image was imported.";}
        catch(Exception ex){MessageBox.Show($"The image could not be opened. {ex.Message}","CIVORA",MessageBoxButton.OK,MessageBoxImage.Error);}
    }

    private void BeginCalibration(){if(PlanImage is null){Status="Import a raster plan before calibrating.";return;}_firstPoint=null;_secondPoint=null;InteractionMode="Calibrate";Status="Click the first end of a known dimension, then click the second end.";OnPropertyChanged(nameof(CalibrationStatus));}
    private void HandlePoint(Point p)
    {
        if(InteractionMode=="Calibrate")
        {
            if(_firstPoint is null){_firstPoint=p;Status="First point saved. Click the other end of the same known dimension.";return;}
            _secondPoint=p;InteractionMode="Select";var distance=(_secondPoint.Value-_firstPoint.Value).Length;PixelDistance=distance;Status=$"Pixel distance: {distance:0.##} px. Enter the real distance and choose its unit, then Apply calibration.";return;
        }
        if(InteractionMode=="Origin")
        {
            _project.CalibrationOriginXPixel=p.X;_project.CalibrationOriginYPixel=p.Y;OnPropertyChanged(nameof(OriginPixelX));OnPropertyChanged(nameof(OriginPixelY));InteractionMode="Select";Status=$"Plan origin set at image pixel ({p.X:0.##}, {p.Y:0.##}). Grid coordinates use this point as (0,0).";return;
        }
        if(InteractionMode=="AddColumn")
        {
            double x,y;
            if(PlanImage is null){x=p.X;y=p.Y;}
            else if(_project.MetresPerPixel is double m&&m>0){var ox=_project.CalibrationOriginXPixel??0;var oy=_project.CalibrationOriginYPixel??PlanImage.PixelHeight;x=(p.X-ox)*m;y=(oy-p.Y)*m;}
            else{x=p.X/PlanImage.PixelWidth*_project.BuildingWidthM;y=(PlanImage.PixelHeight-p.Y)/PlanImage.PixelHeight*_project.BuildingDepthM;}
            AddAt(Math.Clamp(x,0,_project.BuildingWidthM),Math.Clamp(y,0,_project.BuildingDepthM));InteractionMode="Select";Status="Preliminary candidate added. Review its location, section and conflicts.";return;
        }
    }
    public double PixelDistance {get;private set;}
    private void ApplyCalibration()
    {
        if(PixelDistance<=0){Status="Select two points on the plan first.";return;}
        if(!Try(KnownDistanceText,out var distance)){Status="Enter a positive known dimension.";return;}
        try{_project.MetresPerPixel=EngineeringCalculations.CalibrateScale(PixelDistance,distance,CalibrationUnit);_project.CalibrationPixelDistance=PixelDistance;_project.CalibrationKnownMetres=EngineeringCalculations.Convert(distance,CalibrationUnit,"m");OnPropertyChanged(nameof(MetresPerPixel));OnPropertyChanged(nameof(CalibrationStatus));Status=$"Scale calibrated at {_project.MetresPerPixel:0.######} m/pixel. Check with a second known dimension; rotation / skew correction is not applied.";}
        catch(Exception ex){Status=ex.Message;}
    }
    private void GenerateLayout()
    {
        try
        {
            var bw=Parse(WidthText,"Building width");var bd=Parse(DepthText,"Building depth");var span=Parse(SpanText,"Maximum preliminary span");var sw=Parse(SectionWidthText,"Section width");var sd=Parse(SectionDepthText,"Section depth");
            var generated=EngineeringCalculations.GenerateGrid(bw,bd,span,sw,sd);
            Columns.Clear();foreach(var c in generated)Columns.Add(c);SyncColumns();
            if(_project.FloorCount<=0||string.IsNullOrWhiteSpace(_project.BuildingUse)||_project.BuildingUse=="Not specified")Status=$"{Columns.Count} conceptual grid candidates generated for {bw:0.##} × {bd:0.##} m; floor count or building use is missing. No structural safety check has been performed.";
            else Status=$"{Columns.Count} conceptual grid candidates generated. Review every location against walls, openings, circulation, loads and a verified design brief.";
        }
        catch(Exception ex){Status=ex.Message;}
    }
    private void AddAt(double x,double y){var n=Columns.Count+1;while(Columns.Any(c=>c.Id==$"C{n}"))n++;Columns.Add(new StructuralColumn{Id=$"C{n}",X=x,Y=y});SyncColumns();}
    private void MoveColumn(ColumnMove? move){if(move is null)return;move.Column.X=Math.Clamp(move.X,0,_project.BuildingWidthM);move.Column.Y=Math.Clamp(move.Y,0,_project.BuildingDepthM);SyncColumns();}
    private void SyncColumns(){_project.Columns=Columns.ToList();OnPropertyChanged(nameof(Columns));}
    private void SaveProject(){try{_project.Name=ProjectName;_project.DrawingTitle=DrawingTitle;_project.BuildingWidthM=Parse(WidthText,"Building width");_project.BuildingDepthM=Parse(DepthText,"Building depth");_project.MaximumSpanM=Parse(SpanText,"Maximum span");if(!string.IsNullOrWhiteSpace(FloorCountText)&&(!int.TryParse(FloorCountText,out var floors)||floors<=0))throw new ArgumentException("Floor count must be a positive whole number, or left blank if unknown.");SyncColumns();_save(_project);Status="Project saved locally to SQLite.";}catch(Exception e){Status=e.Message;}}
    private void ExportDxf(){var d=new SaveFileDialog{Filter="DXF drawing (*.dxf)|*.dxf",FileName=SafeName(_project.Name)+".dxf"};if(d.ShowDialog()!=true)return;try{DrawingExporter.ExportDxf(Prepare(),d.FileName);Status="DXF exported with structural layers. Raster architectural background is not embedded."; }catch(Exception e){Status=e.Message;}}
    private void ExportPdf(){var d=new SaveFileDialog{Filter="PDF drawing (*.pdf)|*.pdf",FileName=SafeName(_project.Name)+"-drawing.pdf"};if(d.ShowDialog()!=true)return;try{DrawingExporter.ExportDrawingPdf(Prepare(),d.FileName);Status="Vector PDF sheet exported. Imported raster background is omitted."; }catch(Exception e){Status=e.Message;}}
    private void ExportCsv(){var d=new SaveFileDialog{Filter="Column schedule CSV (*.csv)|*.csv",FileName=SafeName(_project.Name)+"-columns.csv"};if(d.ShowDialog()!=true)return;try{DrawingExporter.ExportScheduleCsv(Prepare(),d.FileName);Status="Column schedule CSV exported."; }catch(Exception e){Status=e.Message;}}
    private void ExportJson(){var d=new SaveFileDialog{Filter="CIVORA project JSON (*.json)|*.json",FileName=SafeName(_project.Name)+".json"};if(d.ShowDialog()!=true)return;try{_repository.ExportProjectJson(Prepare(),d.FileName);Status="Project JSON exported."; }catch(Exception e){Status=e.Message;}}
    public void ExportPng(PlanDrawingSurface surface){var d=new SaveFileDialog{Filter="Annotated plan PNG (*.png)|*.png",FileName=SafeName(_project.Name)+"-overlay.png"};if(d.ShowDialog()!=true)return;try{surface.ExportPng(d.FileName);Status="Visible plan overlay exported as PNG."; }catch(Exception e){Status=e.Message;}}
    private CivoraProject Prepare(){_project.Columns=Columns.ToList();_project.Name=ProjectName;_project.DrawingTitle=DrawingTitle;return _project;}
    private static string SafeName(string name)=>string.Concat(name.Select(c=>Path.GetInvalidFileNameChars().Contains(c)?'_':c));
    private static bool Try(string s,out double v)=>double.TryParse(s,NumberStyles.Float,CultureInfo.CurrentCulture,out v)&&double.IsFinite(v);
    private static double Parse(string s,string field)=>Try(s,out var v)&&v>0?v:throw new ArgumentException($"{field} must be a finite value greater than zero.");
}




