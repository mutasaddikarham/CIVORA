using System.IO;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using Civora.Engineering;

namespace Civora.Desktop.ViewModels;

public sealed class DefaultRow : ObservableObject
{
    private double _value;public string Name{get;}public string Unit{get;}public string Category{get;}public string Provenance{get;}public string Assumptions{get;}public string Status{get;private set;}public bool IsEditable{get;}
    public double Value{get=>_value;set=>SetProperty(ref _value,value);}
    public DefaultRow(EngineeringDefault d){Name=d.Name;_value=d.Value;Unit=d.Unit;Category=d.Category;Provenance=d.Provenance;Assumptions=d.Assumptions;Status=d.Status;IsEditable=d.IsEditable;}
    public EngineeringDefault ToModel()=>new(Name,Value,Unit,Category,Provenance,Assumptions,Status,IsEditable);
}

public sealed class DefaultsPageViewModel : ObservableObject
{
    private readonly ProjectRepository _repository;private readonly CivoraProject _project;private readonly Action<CivoraProject> _save;private string _status="Application defaults are available offline; values marked illustrative are not verified code requirements.";
    public string Title{get;}public ObservableCollection<DefaultRow> Defaults{get;}=[];
    public string Status{get=>_status;private set=>SetProperty(ref _status,value);}
    public IReadOnlyList<string> Categories{get;}=["All categories","Material properties","Material densities","Preliminary load values","Section library","Unit preferences","Calculation assumptions","Design code profiles","Masonry"];
    public IRelayCommand SaveOverridesCommand{get;}public IRelayCommand RestoreDefaultsCommand{get;}public IRelayCommand SaveProjectDefaultsCommand{get;}public IRelayCommand ApplyProjectDefaultsCommand{get;}
    public DefaultsPageViewModel(ProjectRepository repository,CivoraProject project,Action<CivoraProject> save,string title){_repository=repository;_project=project;_save=save;Title=title;Load();SaveOverridesCommand=new RelayCommand(SaveOverrides);RestoreDefaultsCommand=new RelayCommand(RestoreDefaults);SaveProjectDefaultsCommand=new RelayCommand(SaveProjectDefaults);ApplyProjectDefaultsCommand=new RelayCommand(ApplyProjectDefaults);}
    private void Load(){Defaults.Clear();foreach(var d in _repository.GetEffectiveDefaults())Defaults.Add(new DefaultRow(d));}
    private void SaveOverrides()
    {
        try{var built=EngineeringDefaultsLibrary.BuiltIn.ToDictionary(d=>d.Name);foreach(var row in Defaults){if(!double.IsFinite(row.Value))throw new ArgumentException($"{row.Name} must be finite.");if(built.TryGetValue(row.Name,out var d)&&row.Value!=d.Value)_repository.SetDefaultOverride(d with{Value=row.Value});else if(row.Value==d?.Value){}}
            Status="Editable application overrides saved locally. Built-in values remain protected.";Load();}
        catch(Exception ex){Status=ex.Message;}
    }
    private void RestoreDefaults(){_repository.RestoreDefaults();Load();Status="Application defaults restored. Existing project-specific values were not changed.";}
    private void SaveProjectDefaults(){_project.MaterialOverrides=Defaults.Where(x=>x.IsEditable).Select(x=>new EngineeringDefault(x.Name,x.Value,x.Unit,x.Category,"Saved from the Engineering Defaults page","Project-specific override; confirm before use.","Project-confirmed",true)).ToList();_save(_project);Status="Current values saved with this project. Global defaults remain separate.";}
    private void ApplyProjectDefaults(){var map=_project.MaterialOverrides.ToDictionary(x=>x.Name,StringComparer.OrdinalIgnoreCase);var count=0;foreach(var row in Defaults)if(map.TryGetValue(row.Name,out var d)&&row.IsEditable){row.Value=d.Value;count++;}Status=count==0?"This project has no saved default overrides.":$"Loaded {count} project-specific values; save them to the project after editing if needed.";}
}

public sealed class ProjectsPageViewModel : ObservableObject
{
    private readonly ProjectRepository _repository;private readonly Action<CivoraProject> _setProject;private readonly Action<string> _navigate;private readonly CivoraProject _current;private string _newName="";private string _status="Projects are stored locally in the CIVORA SQLite database.";private string? _selectedName;
    public ObservableCollection<string> ProjectNames{get;}=[];
    public string NewName{get=>_newName;set=>SetProperty(ref _newName,value);}
    public string? SelectedName{get=>_selectedName;set=>SetProperty(ref _selectedName,value);}
    public string Status{get=>_status;private set=>SetProperty(ref _status,value);}
    public IRelayCommand NewProjectCommand{get;}public IRelayCommand SaveCurrentCommand{get;}public IRelayCommand LoadCommand{get;}public IRelayCommand DuplicateCommand{get;}public IRelayCommand DeleteCommand{get;}
    public ProjectsPageViewModel(ProjectRepository repository,CivoraProject current,Action<CivoraProject> setProject,Action<string> navigate){_repository=repository;_current=current;_setProject=setProject;_navigate=navigate;Refresh();NewProjectCommand=new RelayCommand(NewProject);SaveCurrentCommand=new RelayCommand(()=>{_repository.SaveProject(_current);Refresh();Status="Current project saved locally.";});LoadCommand=new RelayCommand(Load);DuplicateCommand=new RelayCommand(Duplicate);DeleteCommand=new RelayCommand(Delete);}
    private void Refresh(){ProjectNames.Clear();foreach(var p in _repository.ListProjects())ProjectNames.Add(p.Name);if(SelectedName is null&&ProjectNames.Count>0)SelectedName=ProjectNames[0];}
    private void NewProject(){if(string.IsNullOrWhiteSpace(NewName)){Status="Enter a name for the new project.";return;}var project=new CivoraProject{Name=NewName.Trim()};_setProject(project);_repository.SaveProject(project);Refresh();SelectedName=project.Name;NewName="";Status="New local project created.";}
    private void Load(){if(SelectedName is null)return;var p=_repository.LoadProject(SelectedName);if(p is null){Status="Project could not be found.";return;}_setProject(p);Status=$"Loaded '{p.Name}'. Open Plan Analyzer to continue editing.";}
    private void Duplicate(){if(SelectedName is null)return;if(string.IsNullOrWhiteSpace(NewName)){Status="Enter the new project name.";return;}try{_repository.DuplicateProject(SelectedName,NewName.Trim());Refresh();SelectedName=NewName.Trim();Status="Project duplicated.";NewName="";}catch(Exception e){Status=e.Message;}}
    private void Delete(){if(SelectedName is null)return;if(MessageBox.Show($"Delete project '{SelectedName}' from the local CIVORA database?","Delete project",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;_repository.DeleteProject(SelectedName);Refresh();Status="Project deleted.";}
}

public sealed class SchedulePageViewModel : ObservableObject
{
    private readonly CivoraProject _project;private readonly ProjectRepository _repository;private string _status="Schedule rows share the current project column objects.";
    public ObservableCollection<StructuralColumn> Columns{get;}=[];
    public string Status{get=>_status;private set=>SetProperty(ref _status,value);}
    public IRelayCommand RenumberCommand{get;}public IRelayCommand ExportCommand{get;}public IRelayCommand SaveCommand{get;}
    public SchedulePageViewModel(CivoraProject project,ProjectRepository repository){_project=project;_repository=repository;foreach(var c in project.Columns)Columns.Add(c);RenumberCommand=new RelayCommand(Renumber);ExportCommand=new RelayCommand(Export);SaveCommand=new RelayCommand(()=>{_project.Columns=Columns.ToList();_repository.SaveProject(_project);Status="Schedule edits saved with the project.";});}
    private void Renumber(){var i=1;foreach(var c in Columns.OrderBy(c=>c.Y).ThenBy(c=>c.X))c.Id=$"C{i++}";_project.Columns=Columns.ToList();Status="Column IDs renumbered by Y then X coordinate. Review the labels on the drawing.";OnPropertyChanged(nameof(Columns));}
    private void Export(){var d=new SaveFileDialog{Filter="Column schedule CSV (*.csv)|*.csv",FileName=string.Concat(_project.Name.Select(c=>Path.GetInvalidFileNameChars().Contains(c)?'_':c))+"-columns.csv"};if(d.ShowDialog()!=true)return;_project.Columns=Columns.ToList();DrawingExporter.ExportScheduleCsv(_project,d.FileName);Status="Column schedule CSV exported.";}
}

public sealed record HistoryRow(string Title,string Result,string Created);
public sealed class HistoryPageViewModel : ObservableObject
{
    private readonly ProjectRepository _repository;private readonly string _projectName;private string _query="";private string _status="Calculation history is stored locally.";public ObservableCollection<HistoryRow> Items{get;}=[];
    public string Query{get=>_query;set=>SetProperty(ref _query,value);}
    public string Status{get=>_status;private set=>SetProperty(ref _status,value);}
    public IRelayCommand SearchCommand{get;}public IRelayCommand ExportCommand{get;}
    public HistoryPageViewModel(ProjectRepository repository,string projectName){_repository=repository;_projectName=projectName;SearchCommand=new RelayCommand(Search);ExportCommand=new RelayCommand(Export);Search();}
    private void Search(){Items.Clear();foreach(var x in _repository.SearchHistory(string.IsNullOrWhiteSpace(Query)?null:Query))Items.Add(new(x.Title,x.Result,x.Created.ToLocalTime().ToString("g",CultureInfo.CurrentCulture)));Status=$"{Items.Count} saved calculations shown.";}
    private void Export(){var d=new SaveFileDialog{Filter="Calculation summary CSV (*.csv)|*.csv",FileName="CIVORA-calculations.csv"};if(d.ShowDialog()!=true)return;var b=new System.Text.StringBuilder("Title,Result,Created local\r\n");foreach(var h in _repository.SearchHistory(Query))b.AppendLine($"{Csv(h.Title)},{Csv(h.Result)},{Csv(h.Created.ToLocalTime().ToString("g"))}");File.WriteAllText(d.FileName,b.ToString());Status="Calculation history CSV exported.";}
    private static string Csv(string s) => ((char)34) + s.Replace(((char)34).ToString(), new string((char)34,2)) + ((char)34);
}

public sealed class ReportsPageViewModel : ObservableObject
{
    private readonly ProjectRepository _repository;private readonly CivoraProject _project;private string _status="Create a local vector drawing sheet, calculation summary or editable JSON project file.";
    public string Status{get=>_status;private set=>SetProperty(ref _status,value);}
    public IRelayCommand DrawingPdfCommand{get;}public IRelayCommand ReportPdfCommand{get;}public IRelayCommand JsonCommand{get;}public IRelayCommand DxfCommand{get;}
    public ReportsPageViewModel(ProjectRepository repository,CivoraProject project){_repository=repository;_project=project;DrawingPdfCommand=new RelayCommand(DrawingPdf);ReportPdfCommand=new RelayCommand(ReportPdf);JsonCommand=new RelayCommand(Json);DxfCommand=new RelayCommand(Dxf);}
    private string FileName(string suffix)=>string.Concat(_project.Name.Select(c=>Path.GetInvalidFileNameChars().Contains(c)?'_':c))+suffix;
    private void DrawingPdf(){var d=new SaveFileDialog{Filter="PDF drawing (*.pdf)|*.pdf",FileName=FileName("-drawing.pdf")};if(d.ShowDialog()!=true)return;DrawingExporter.ExportDrawingPdf(_project,d.FileName);Status="PDF vector drawing exported. The imported raster architectural background is not embedded.";}
    private void ReportPdf(){var d=new SaveFileDialog{Filter="PDF report (*.pdf)|*.pdf",FileName=FileName("-report.pdf")};if(d.ShowDialog()!=true)return;DrawingExporter.ExportCalculationReportPdf(_project.Name,_repository.SearchHistory(),d.FileName);Status="PDF calculation summary exported.";}
    private void Json(){var d=new SaveFileDialog{Filter="CIVORA project JSON (*.json)|*.json",FileName=FileName(".json")};if(d.ShowDialog()!=true)return;_repository.ExportProjectJson(_project,d.FileName);Status="Project JSON exported.";}
    private void Dxf(){var d=new SaveFileDialog{Filter="DXF drawing (*.dxf)|*.dxf",FileName=FileName(".dxf")};if(d.ShowDialog()!=true)return;DrawingExporter.ExportDxf(_project,d.FileName);Status="Layered DXF structural overlay exported.";}
}

public sealed class AboutPageViewModel
{
    public string Title=>"CIVORA";public string Tagline=>"Calculate Smarter. Design Better. Build the Future.";public string BuilderCredit=>"Built by Er. Md Mutasaddik Arham";
    public string Version=>$"CIVORA Preview • Engineering defaults {EngineeringDefaultsLibrary.Version} • .NET 10 / WPF";
    public string Notice=>"CIVORA provides educational and preliminary quantity / analysis tools. It does not implement verified BNBC, ACI, or other design-code checks. Candidate column layouts and idealized calculations must be reviewed by a qualified engineer before construction.";
    public string Data=>"Projects, overrides and calculation history are stored locally in a SQLite database. Basic calculations and drawing exports run offline. The app does not send project data to a server.";
}



