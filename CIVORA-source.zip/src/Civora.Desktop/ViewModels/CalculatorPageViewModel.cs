using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Civora.Engineering;

namespace Civora.Desktop.ViewModels;

public sealed class CalcField : ObservableObject
{
    private string _value;public string Name{get;}public string Unit{get;}
    public string Value{get=>_value;set=>SetProperty(ref _value,value);}
    public CalcField(string name,string value,string unit="—"){Name=name;_value=value;Unit=unit;}
}

public sealed class CalculatorPageViewModel : ObservableObject
{
    private readonly string _title;private readonly ProjectRepository _repository;private readonly CivoraProject _project;private string _selectedMode="";private string _result="Enter values, then calculate.";private string _formula="";private string _steps="";private string _assumptions="";private string _limitation="";
    public string Title=>_title;public string Description=>DescriptionFor(_title);
    public ObservableCollection<string> Modes{get;}=[];
    public ObservableCollection<CalcField> Fields{get;}=[];
    public string SelectedMode{get=>_selectedMode;set{if(SetProperty(ref _selectedMode,value))BuildFields();}}
    public string Result{get=>_result;private set=>SetProperty(ref _result,value);}
    public string Formula{get=>_formula;private set=>SetProperty(ref _formula,value);}
    public string Steps{get=>_steps;private set=>SetProperty(ref _steps,value);}
    public string Assumptions{get=>_assumptions;private set=>SetProperty(ref _assumptions,value);}
    public string Limitation{get=>_limitation;private set=>SetProperty(ref _limitation,value);}
    public IRelayCommand CalculateCommand{get;}public IRelayCommand CopyCommand{get;}

    public CalculatorPageViewModel(string title,CivoraProject project,ProjectRepository repository){_title=title;_project=project;_repository=repository;SetModes();SelectedMode=Modes.FirstOrDefault()??"";CalculateCommand=new RelayCommand(Calculate);CopyCommand=new RelayCommand(()=>Clipboard.SetText($"{Title}\n{Formula}\n{Steps}\n{Result}\nAssumptions: {Assumptions}\nLimitations: {Limitation}"));}
    private void SetModes()
    {
        string[] modes=_title switch
        {
            "Scale Calculator"=>["Drawing length to actual length"],
            "Unit Converter"=>["Convert compatible units"],
            "Geometry & Area"=>["Rectangle","Triangle","Circle","Trapezoid"],
            "Concrete & Materials"=>["Slab volume","Beam volume","Column volume","Footing volume","Stair waist slab volume","Concrete material estimate"],
            "Structural Loads"=>["Area load to line load"],
            "Beam Analysis"=>["Simply supported • point load","Simply supported • UDL","Cantilever • point load","Cantilever • UDL"],
            "Column Analysis"=>["Rectangular column area and average stress"],
            "Foundation Calculator"=>["Concentric footing bearing pressure"],
            "Reinforcement Calculator"=>["Bar weight and total mass","Bars from spacing"],
            "Brickwork Calculator"=>["Net wall volume, bricks and mortar"],
            "Surveying Tools"=>["Coordinate distance","Gradient","Reduced level • height of instrument"],
            _=>["Supported engineering calculation"]
        };
        foreach(var mode in modes)Modes.Add(mode);
    }
    private void BuildFields()
    {
        Fields.Clear();
        void Add(string name,string value,string unit="—")=>Fields.Add(new CalcField(name,value,unit));
        switch(_title)
        {
            case "Scale Calculator":Add("Drawing length","100","mm");Add("Scale denominator",Default("Default scale denominator",100).ToString(CultureInfo.InvariantCulture),"ratio");break;
            case "Unit Converter":Add("Value","1");Add("From unit","m");Add("To unit","ft");break;
            case "Geometry & Area":
                if(SelectedMode=="Rectangle"){Add("Width","6","m");Add("Height","4","m");}
                else if(SelectedMode=="Triangle"){Add("Base","6","m");Add("Height","4","m");}
                else if(SelectedMode=="Circle")Add("Diameter","6","m");
                else{Add("Parallel side A","4","m");Add("Parallel side B","8","m");Add("Height","3","m");}break;
            case "Concrete & Materials":
                if(SelectedMode=="Slab volume"){Add("Length","6","m");Add("Width","4","m");Add("Thickness","0.15","m");}
                else if(SelectedMode=="Beam volume"){Add("Length","5","m");Add("Width","0.3","m");Add("Depth","0.5","m");}
                else if(SelectedMode=="Column volume"){Add("Height","3","m");Add("Width","0.3","m");Add("Depth","0.3","m");}
                else if(SelectedMode=="Footing volume"){Add("Length","2","m");Add("Width","2","m");Add("Thickness","0.45","m");}
                else if(SelectedMode=="Stair waist slab volume"){Add("Width","1.2","m");Add("Waist thickness","0.15","m");Add("Horizontal run","3.6","m");Add("Rise","1.5","m");}
                else{Add("Wet volume","1","m³");Add("Dry volume factor",Default("Concrete dry-volume factor",1.54).ToString(CultureInfo.InvariantCulture),"—");Add("Cement parts",Default("Concrete mix ratio — cement",1).ToString(CultureInfo.InvariantCulture),"parts");Add("Sand parts",Default("Concrete mix ratio — sand",2).ToString(CultureInfo.InvariantCulture),"parts");Add("Aggregate parts",Default("Concrete mix ratio — aggregate",4).ToString(CultureInfo.InvariantCulture),"parts");Add("Cement density",Default("Cement bulk density",1440).ToString(CultureInfo.InvariantCulture),"kg/m³");Add("Sand density",Default("Sand bulk density",1600).ToString(CultureInfo.InvariantCulture),"kg/m³");Add("Aggregate density",Default("Coarse aggregate bulk density",1500).ToString(CultureInfo.InvariantCulture),"kg/m³");}break;
            case "Structural Loads":Add("Area load",Default("Residential floor live load",2).ToString(CultureInfo.InvariantCulture),"kN/m²");Add("Tributary width","3","m");break;
            case "Beam Analysis":
                Add("Span / length","6","m");
                if(SelectedMode.Contains("point")){Add("Point load","12","kN");if(SelectedMode.StartsWith("Simply"))Add("Distance from left support","2","m");}
                else Add("Uniform load","10","kN/m");break;
            case "Column Analysis":Add("Width",Default("Column section — 300 × 300",300).ToString(CultureInfo.InvariantCulture),"mm");Add("Depth",Default("Column section — 300 × 300",300).ToString(CultureInfo.InvariantCulture),"mm");Add("Axial service load","900","kN");break;
            case "Foundation Calculator":Add("Service load","400","kN");Add("Footing length","2","m");Add("Footing width","2","m");break;
            case "Reinforcement Calculator":
                if(SelectedMode=="Bar weight and total mass"){Add("Bar diameter",Default("Default reinforcing bar diameter",12).ToString(CultureInfo.InvariantCulture),"mm");Add("Length per bar","12","m");Add("Bar count","10","bars");}
                else{Add("Clear length","4000","mm");Add("Spacing","200","mm");}break;
            case "Brickwork Calculator":Add("Wall length","5","m");Add("Wall height","3","m");Add("Wall thickness","0.23","m");Add("Opening area","2","m²");Add("Brick length",Default("Brick dimensions — length",240).ToString(CultureInfo.InvariantCulture),"mm");Add("Brick width",Default("Brick dimensions — width",115).ToString(CultureInfo.InvariantCulture),"mm");Add("Brick height",Default("Brick dimensions — height",70).ToString(CultureInfo.InvariantCulture),"mm");Add("Mortar joint","10","mm");break;
            case "Surveying Tools":
                if(SelectedMode=="Coordinate distance"){Add("X1","0","m");Add("Y1","0","m");Add("X2","30","m");Add("Y2","40","m");}
                else if(SelectedMode=="Gradient"){Add("Rise","1.5","m");Add("Horizontal run","30","m");}
                else{Add("Benchmark RL","100","m");Add("Backsight","1.25","m");Add("Foresight","2.1","m");}break;
            default:Add("Length","5","m");break;
        }
    }
    private double Default(string name,double fallback){var project=_project.MaterialOverrides?.FirstOrDefault(x=>string.Equals(x.Name,name,StringComparison.OrdinalIgnoreCase));if(project is not null)return project.Value;var global=_repository.GetEffectiveDefaults().FirstOrDefault(x=>string.Equals(x.Name,name,StringComparison.OrdinalIgnoreCase));return global?.Value??fallback;}
    private double V(string name){var s=Fields.Single(f=>f.Name==name).Value;if(!double.TryParse(s,NumberStyles.Float,CultureInfo.CurrentCulture,out var x)||!double.IsFinite(x))throw new ArgumentException($"{name} must be a finite number.");return x;}
    private string S(string name)=>Fields.Single(f=>f.Name==name).Value.Trim();
    private void Calculate()
    {
        try
        {
            CalculationResult r;
            switch(_title)
            {
                case "Scale Calculator":var scaleResult=EngineeringCalculations.Scale(V("Drawing length"),V("Scale denominator"));r=scaleResult with{Inputs=new Dictionary<string,string>{{"Drawing length",$"{V("Drawing length")} mm"},{"Scale denominator",$"1:{V("Scale denominator")}"}}};break;
                case "Unit Converter":
                    var cv=EngineeringCalculations.Convert(V("Value"),S("From unit"),S("To unit"));
                    r=new("Unit conversion","Converted value = input × source-unit factor ÷ target-unit factor",new Dictionary<string,string>{{"Input",$"{S("Value")} {S("From unit")}"},{"Target unit",S("To unit")}},[$"{V("Value"):0.####} {S("From unit")} = {cv:0.####} {S("To unit")}"],$"{cv:0.####} {S("To unit")}","Units must belong to a supported compatible dimension.","Conversions do not make unlike physical dimensions compatible.");break;
                case "Geometry & Area":
                    var area=SelectedMode switch{"Rectangle"=>EngineeringCalculations.RectangleArea(V("Width"),V("Height")),"Triangle"=>EngineeringCalculations.TriangleArea(V("Base"),V("Height")),"Circle"=>EngineeringCalculations.CircleArea(V("Diameter")),_=>EngineeringCalculations.TrapezoidArea(V("Parallel side A"),V("Parallel side B"),V("Height"))};
                    var formula=SelectedMode switch{"Rectangle"=>"A = b × h","Triangle"=>"A = ½ × base × height","Circle"=>"A = π × (diameter / 2)²",_=>"A = (a + b) × h / 2"};
                    r=Simple(SelectedMode,formula,$"Area = {area:0.####} m²","All lengths are entered in metres.","Polygon boundaries must be closed; composite shapes should be split into supported pieces.");break;
                case "Concrete & Materials":
                    if(SelectedMode=="Concrete material estimate"){var m=EngineeringCalculations.EstimateConcreteMaterials(V("Wet volume"),V("Cement parts"),V("Sand parts"),V("Aggregate parts"),V("Dry volume factor"),V("Cement density"),V("Sand density"),V("Aggregate density"));r=Simple("Concrete material estimate","Dry volume = wet volume × editable factor; component volumes use selected mix parts; cement mass uses selected bulk density",$"Cement ≈ {m.CementKg:0.##} kg\nSand ≈ {m.SandM3:0.####} m³\nAggregate ≈ {m.AggregateM3:0.####} m³","Illustrative 1.54 dry-volume factor and mass/volume inputs; 1:2:4 is only a starting ratio.","This is a rough quantity estimate, not a mix design, yield test, or strength specification.");}
                    else{var length=SelectedMode=="Column volume"?V("Height"):V("Length");var third=SelectedMode=="Beam volume"||SelectedMode=="Column volume"?"Depth":"Thickness";var volume=SelectedMode switch{"Stair waist slab volume"=>EngineeringCalculations.StairWaistSlabVolume(V("Width"),V("Waist thickness"),V("Horizontal run"),V("Rise")),_=>EngineeringCalculations.ConcreteVolume(length,V("Width"),V(third))};r=Simple($"{SelectedMode} concrete volume","Volume = length × width × thickness / depth",$"Concrete volume = {volume:0.####} m³","Dimensions are entered in metres; concrete shape is treated as a simple prism.","Does not deduct intersections, openings, reinforcement displacement, wastage or construction tolerances.");}break;
                case "Structural Loads":var line=EngineeringCalculations.LineLoadFromAreaLoad(V("Area load"),V("Tributary width"));r=Simple("Area load to line load","w(line) = q(area) × tributary width",$"Line load = {line:0.####} kN/m","Illustrative service-load conversion using a user-entered tributary width.","No load combinations, patterns, dynamic effects or code factors are applied.");break;
                case "Beam Analysis":var len=V("Span / length");BeamResult b=SelectedMode switch{"Simply supported • point load"=>EngineeringCalculations.SimplySupportedPoint(V("Point load"),len,V("Distance from left support")),"Simply supported • UDL"=>EngineeringCalculations.SimplySupportedUniform(V("Uniform load"),len),"Cantilever • point load"=>EngineeringCalculations.CantileverPoint(V("Point load"),len),_=>EngineeringCalculations.CantileverUniform(V("Uniform load"),len)};r=Simple(SelectedMode,"Reactions from static equilibrium; max moment and shear for the idealized case",$"Left reaction = {b.LeftReactionKn:0.####} kN\nRight reaction = {b.RightReactionKn:0.####} kN\nMaximum shear = {b.MaximumShearKn:0.####} kN\nMaximum moment = {b.MaximumMomentKnM:0.####} kN·m","Prismatic, linear-elastic-free static equilibrium model; loads are entered as service / nominal values.","No deflection, self-weight, distributed interaction, combinations, design capacities, or code checks. Internal force diagrams are not included.");break;
                case "Column Analysis":var c=EngineeringCalculations.ColumnAverageStress(V("Width"),V("Depth"),V("Axial service load"));r=Simple("Column section and average axial stress","A = b × h; σ(avg) = P / A",$"Gross area = {c.AreaM2:0.####} m²\nAverage axial stress = {c.StressMpa:0.####} MPa","Gross rectangular area and concentric axial load; 1 MPa = 1 N/mm².","Not a column capacity, stability, slenderness, reinforcement, eccentricity, or code design check.");break;
                case "Foundation Calculator":var f=EngineeringCalculations.FootingBearing(V("Service load"),V("Footing length"),V("Footing width"));r=Simple("Concentric footing bearing estimate","A = L × B; q(avg) = service load / area",$"Footing area = {f.AreaM2:0.####} m²\nAverage bearing pressure = {f.BearingPressureKpa:0.####} kPa","Concentric service load and uniform contact pressure assumed.","No soil parameters, eccentricity, settlement, groundwater, footing self-weight, structural design, or code factors.");break;
                case "Reinforcement Calculator":
                    if(SelectedMode=="Bar weight and total mass"){var dia=V("Bar diameter");var barLength=V("Length per bar");var count=V("Bar count");r=Simple("Reinforcement bar mass","Unit mass = d² / 162; total = unit mass × length × count",$"Theoretical unit mass = {EngineeringCalculations.BarWeightKgPerM(dia):0.####} kg/m\nTotal mass = {EngineeringCalculations.ReinforcementWeightKg(dia,barLength,count):0.####} kg","Nominal bar diameter in millimetres; theoretical density-based approximation.","Does not include hooks, laps, bends, wastage, cutting tolerances, or manufacturer mass tolerance.");}
                    else{var count=EngineeringCalculations.BarsForSpacing(V("Clear length"),V("Spacing"));r=Simple("Bars from spacing","Number of bars = ceiling(clear length / spacing) + 1",$"Estimated bar count = {count}","Evenly spaced bars with one bar at each end of the entered clear length.","Cover, support, anchorage, bending and code-specific spacing limits are not considered.");}break;
                case "Brickwork Calculator":var bw=EngineeringCalculations.Brickwork(V("Wall length"),V("Wall height"),V("Wall thickness"),V("Opening area"),V("Brick length"),V("Brick width"),V("Brick height"),V("Mortar joint"));r=Simple("Brickwork quantity estimate","Net wall volume = (length × height − openings) × thickness; units use brick + joint module",$"Net wall volume = {bw.NetVolumeM3:0.####} m³\nEstimated brick count = {bw.BrickCount:0.##}\nEstimated mortar volume = {bw.MortarVolumeM3:0.####} m³","Rectangular wall, user-entered opening area and uniform mortar joint assumed.","No bond pattern, breakage, workmanship, varying openings, lintels, or mortar mix design included.");break;
                case "Surveying Tools":
                    if(SelectedMode=="Coordinate distance"){var d=EngineeringCalculations.CoordinateDistance(V("X1"),V("Y1"),V("X2"),V("Y2"));r=Simple("Coordinate distance","d = √((x₂ − x₁)² + (y₂ − y₁)²)",$"Horizontal distance = {d:0.####} m","Planar Cartesian coordinates in metres.","No curvature, bearing, projection, or instrument corrections applied.");}
                    else if(SelectedMode=="Gradient"){var g=EngineeringCalculations.GradientPercent(V("Rise"),V("Horizontal run"));r=Simple("Gradient","Gradient (%) = rise / horizontal run × 100",$"Gradient = {g:0.####}%","Rise magnitude and horizontal run are entered in metres.","Does not indicate direction unless rise sign is reviewed separately.");}
                    else{var rl=EngineeringCalculations.ReducedLevelFromHeightOfInstrument(V("Benchmark RL"),V("Backsight"),V("Foresight"));r=Simple("Reduced level • height of instrument","HI = benchmark RL + backsight; RL = HI − foresight",$"Height of instrument = {V("Benchmark RL")+V("Backsight"):0.####} m\nReduced level = {rl:0.####} m","Single setup using the height-of-instrument method.","No closure error, curvature/refraction correction, intermediate sight sequence or adjustment included.");}break;
                default:throw new NotSupportedException("This module does not have an implemented calculator.");
            }
            Formula=r.Formula;Steps=string.Join("\n",r.Steps);Assumptions=r.Assumptions;Limitation=r.Limitation;Result=r.Result;_repository.SaveHistory(r.Title,$"{r.Result}\\nFormula: {r.Formula}\\nInputs and steps:\\n{Steps}\\nAssumptions: {r.Assumptions}\\nLimitations: {r.Limitation}");
        }
        catch(Exception ex){Result=$"Cannot calculate: {ex.Message}";Formula="Check input values and units.";Steps="No result was saved.";Assumptions="";Limitation="";}
    }
    private CalculationResult Simple(string title,string formula,string result,string assumptions,string limitation){var inputs=string.Join("; ",Fields.Select(f=>$"{f.Name} = {f.Value} {f.Unit}"));return new(title,formula,new Dictionary<string,string>(),[$"Inputs: {inputs}",formula,result],result,assumptions,limitation);}
    private static string DescriptionFor(string title)=>title switch{"Scale Calculator"=>"Relate a paper or screen length to its drawing scale.","Unit Converter"=>"Convert compatible engineering units with explicit source and target units.","Geometry & Area"=>"Calculate common planar shapes using dimensions in metres.","Concrete & Materials"=>"Calculate simple prism quantities and illustrative nominal material quantities.","Structural Loads"=>"Convert user-entered area loading to line load by tributary width.","Beam Analysis"=>"Find reactions, peak shear and peak moment for supported idealized beam cases.","Column Analysis"=>"Calculate gross rectangular section area and average concentric stress.","Foundation Calculator"=>"Estimate average bearing pressure for a concentric service load.","Reinforcement Calculator"=>"Estimate bar mass or bar count from a uniform spacing.","Brickwork Calculator"=>"Estimate net wall volume, brick count and mortar volume.","Surveying Tools"=>"Calculate planar distance, grade and a single setup reduced level.",_=>"PRELIMINARY ESTIMATE — DESIGN CODE NOT VERIFIED. This application does not perform verified code design checks."};
}






