using Civora.Engineering;

namespace Civora.Tests;

public class EngineeringTests
{
    [Fact] public void ScaleCalibrationConvertsKnownUnits() => Assert.Equal(0.05,EngineeringCalculations.CalibrateScale(100,5,"m"),10);
    [Fact] public void UnitConverterConvertsLengthAndTemperature() { Assert.Equal(3.280839895,EngineeringCalculations.Convert(1,"m","ft"),6); Assert.Equal(68,EngineeringCalculations.Convert(20,"°C","°F"),8); }
    [Fact] public void GeometryAreasAreCorrect() { Assert.Equal(24,EngineeringCalculations.RectangleArea(6,4)); Assert.Equal(12,EngineeringCalculations.TriangleArea(6,4)); Assert.Equal(Math.PI*9,EngineeringCalculations.CircleArea(6),10); }
    [Fact] public void PolygonAreaUsesShoelace() => Assert.Equal(12,EngineeringCalculations.PolygonArea([(0,0),(4,0),(4,3),(0,3)]));
    [Fact] public void ConcreteVolumeIsGeometric() => Assert.Equal(1.2,EngineeringCalculations.ConcreteVolume(4,3,0.1),10);
    [Fact] public void RebarWeightUsesRequestedFormula() { Assert.Equal(16.0/162,EngineeringCalculations.BarWeightKgPerM(4),10); Assert.Equal(12.0*12*10*2/162,EngineeringCalculations.ReinforcementWeightKg(12,10,2),10); }
    [Fact] public void BeamUniformLoadReactionsAndMomentAreSymmetric() { var b=EngineeringCalculations.SimplySupportedUniform(10,6); Assert.Equal(30,b.LeftReactionKn); Assert.Equal(45,b.MaximumMomentKnM); }
    [Fact] public void BeamPointLoadReactionsRespectPosition() { var b=EngineeringCalculations.SimplySupportedPoint(12,6,2); Assert.Equal(8,b.LeftReactionKn); Assert.Equal(4,b.RightReactionKn); Assert.Equal(16,b.MaximumMomentKnM); }
    [Fact] public void CantileverUniformLoadMomentIsAtFixedEnd() { var b=EngineeringCalculations.CantileverUniform(4,3); Assert.Equal(12,b.MaximumShearKn); Assert.Equal(18,b.MaximumMomentKnM); }
    [Fact] public void ColumnAverageStressIsInMpa() { var (area,stress)=EngineeringCalculations.ColumnAverageStress(300,300,900); Assert.Equal(.09,area,10); Assert.Equal(10,stress,10); }
    [Fact] public void FootingBearingPressureUsesServiceLoad() { var (area,q)=EngineeringCalculations.FootingBearing(400,2,2); Assert.Equal(4,area); Assert.Equal(100,q); }
    [Fact] public void GridKeepsSpansWithinMaximumAndStartsAtOrigin() { var grid=EngineeringCalculations.GenerateGrid(10,8,4); Assert.Equal(12,grid.Count); Assert.Contains(grid,c=>c.X==0&&c.Y==0); var xs=grid.Select(c=>c.X).Distinct().OrderBy(x=>x).ToArray(); var ys=grid.Select(c=>c.Y).Distinct().OrderBy(y=>y).ToArray(); Assert.True(xs.Zip(xs.Skip(1),(a,b)=>b-a).Max()<=4); Assert.True(ys.Zip(ys.Skip(1),(a,b)=>b-a).Max()<=4); }
    [Fact] public void InvalidDimensionsAreRejected() => Assert.Throws<ArgumentOutOfRangeException>(()=>EngineeringCalculations.ConcreteVolume(1,0,1));
    [Fact] public void BuiltInDefaultsArePreloadedAndExplicitlyIllustrative() { Assert.Contains(EngineeringDefaultsLibrary.BuiltIn,d=>d.Name.Contains("C25")&&d.Value==25); Assert.Contains(EngineeringDefaultsLibrary.BuiltIn,d=>d.Category=="Preliminary load values"&&d.Status=="Illustrative default"); }
    [Fact] public void OverridesAreStoredSeparatelyAndCanBeRestored() { var dir=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);var repo=new ProjectRepository(Path.Combine(dir,"t.db"));var d=repo.GetEffectiveDefaults().Single(x=>x.Name.Contains("C25"));repo.SetDefaultOverride(d with{Value=28});Assert.Equal(28,repo.GetEffectiveDefaults().Single(x=>x.Name.Contains("C25")).Value);repo.RestoreDefaults();Assert.Equal(25,repo.GetEffectiveDefaults().Single(x=>x.Name.Contains("C25")).Value);Directory.Delete(dir,true); }
[Fact] public void ProjectsPersistWithoutReplacingMaterialAssignments()
    {
        var dir=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        try
        {
            var repo=new ProjectRepository(Path.Combine(dir,"t.db"));
            var builtIn=repo.GetEffectiveDefaults().Single(x=>x.Name.Contains("C25"));
            var project=new CivoraProject{Name="test",MaterialOverrides=[builtIn with{Value=32,Status="Project-confirmed"}]};
            repo.SaveProject(project);
            repo.SetDefaultOverride(builtIn with{Value=28});
            var loaded=repo.LoadProject("test")!;
            Assert.Equal(32,loaded.MaterialOverrides.Single().Value);
            Assert.Equal(28,repo.GetEffectiveDefaults().Single(x=>x.Name.Contains("C25")).Value);
            Assert.Single(repo.ListProjects());
        }
        finally
        {
            Directory.Delete(dir,true);
        }
    }
    [Fact] public void ExportsWriteRealFiles() { var dir=Path.Combine(Path.GetTempPath(),Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);var p=new CivoraProject{Name="Export test",Columns=EngineeringCalculations.GenerateGrid(4,4,4).ToList()};var csv=Path.Combine(dir,"a.csv");var dxf=Path.Combine(dir,"a.dxf");var pdf=Path.Combine(dir,"a.pdf");DrawingExporter.ExportScheduleCsv(p,csv);DrawingExporter.ExportDxf(p,dxf);DrawingExporter.ExportDrawingPdf(p,pdf);Assert.Contains("Column ID",File.ReadAllText(csv));Assert.StartsWith("0",File.ReadAllText(dxf));Assert.StartsWith("%PDF-1.4",File.ReadAllText(pdf));Directory.Delete(dir,true); }
}


