using Civora.Engineering;

namespace Civora.Tests;

public class EngineeringDefaultsTests
{
    [Fact]
    public void FirstLaunchSeedsVersionedDefaultsWithCompleteProvenance()
    {
        var directory = Path.Combine(Path.GetTempPath(), Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        try
        {
            var repository = new ProjectRepository(Path.Combine(directory, "first-launch.db"));
            var defaults = repository.GetEffectiveDefaults();

            Assert.Equal(36, defaults.Count);
            Assert.All(defaults, item =>
            {
                Assert.False(string.IsNullOrWhiteSpace(item.Name));
                Assert.False(string.IsNullOrWhiteSpace(item.Unit));
                Assert.False(string.IsNullOrWhiteSpace(item.Category));
                Assert.False(string.IsNullOrWhiteSpace(item.Provenance));
                Assert.False(string.IsNullOrWhiteSpace(item.Assumptions));
                Assert.False(string.IsNullOrWhiteSpace(item.Status));
            });
            Assert.Contains(defaults, item => item.Name.Contains("C25") && item.Value == 25);
        }
        finally
        {
            Directory.Delete(directory, true);
        }
    }
}
